import { createFileRoute, Link } from "@tanstack/react-router";
import { queryOptions, useMutation, useSuspenseQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  useMemo,
  useState,
  type FormEvent,
  type ComponentType,
  type ReactNode,
  type CSSProperties,
} from "react";
import { Combobox, type ComboboxItem } from "@/components/Combobox";
import { useRecent } from "@/hooks/useRecent";
import {
  Bar,
  BarChart,
  Cell,
  Pie,
  PieChart,
  PolarAngleAxis,
  RadialBar,
  RadialBarChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  Plane,
  Gauge,
  Fuel,
  Users,
  Clock,
  TrendingUp,
  Route as RouteIcon,
  AlertTriangle,
  ArrowLeft,
  Wallet,
  Target,
  PlayCircle,
} from "lucide-react";
import {
  analyzeRouteFn,
  listAircraft,
  listAirports,
  type AnalyzeInputT,
} from "@/lib/routes.functions";
import type { RouteAnalysis } from "@/types/domain";

const aircraftQuery = queryOptions({
  queryKey: ["aircraft"],
  queryFn: () => listAircraft(),
});
const airportsQuery = queryOptions({
  queryKey: ["airports"],
  queryFn: () => listAirports(),
});

export const Route = createFileRoute("/planner")({
  head: () => ({
    meta: [
      { title: "Route Planner — Silesian Airways Analyzer" },
      {
        name: "description",
        content:
          "Evaluate regional airline routes: fuel, fees, crew, and profitability in EUR.",
      },
      { property: "og:title", content: "Route Planner — Silesian Airways Analyzer" },
      {
        property: "og:description",
        content: "Route economics for regional airline planning.",
      },
    ],
  }),
  loader: async ({ context }) => {
    await Promise.all([
      context.queryClient.ensureQueryData(aircraftQuery),
      context.queryClient.ensureQueryData(airportsQuery),
    ]);
  },
  component: PlannerPage,
});

const eur = (n: number) =>
  new Intl.NumberFormat("en-IE", {
    style: "currency",
    currency: "EUR",
    maximumFractionDigits: 0,
  }).format(n);
const pct = (n: number) => `${(n * 100).toFixed(1)}%`;

const classificationMeta: Record<
  RouteAnalysis["classification"],
  { label: string; badge: string; ring: string; token: string }
> = {
  "highly-profitable": {
    label: "Highly Profitable",
    badge: "bg-success/15 text-success border-success/40",
    ring: "text-success",
    token: "var(--success)",
  },
  profitable: {
    label: "Profitable",
    badge: "bg-success/10 text-success border-success/30",
    ring: "text-success",
    token: "var(--success)",
  },
  "break-even": {
    label: "Break-Even",
    badge: "bg-warning/15 text-warning border-warning/40",
    ring: "text-warning",
    token: "var(--warning)",
  },
  risky: {
    label: "Risky",
    badge: "bg-warning/15 text-warning border-warning/40",
    ring: "text-warning",
    token: "var(--warning)",
  },
  "not-recommended": {
    label: "Not Recommended",
    badge: "bg-danger/15 text-danger border-danger/40",
    ring: "text-danger",
    token: "var(--danger)",
  },
};

const COST_COLORS = [
  "#3b6fa0",
  "#5b9bd5",
  "#7ebfe0",
  "#4ade80",
  "#22c55e",
  "#facc15",
  "#fb923c",
  "#f97316",
  "#ef4444",
  "#c084fc",
  "#a78bfa",
  "#94a3b8",
];

function PlannerPage() {
  const { data: aircraft } = useSuspenseQuery(aircraftQuery);
  const { data: airports } = useSuspenseQuery(airportsQuery);

  const [departureIcao, setDeparture] = useState(airports[0]?.icao ?? "");
  const [destinationIcao, setDestination] = useState(airports[1]?.icao ?? "");
  const [aircraftId, setAircraftId] = useState(aircraft[1]?.id ?? aircraft[0]?.id ?? "");
  const [loadFactor, setLoadFactor] = useState(72);
  const [fare, setFare] = useState(120);
  const [fuelPrice, setFuelPrice] = useState(0.85);

  const [recentAirports, pushRecentAirport] = useRecent("recent-airports");
  const [recentAircraft, pushRecentAircraft] = useRecent("recent-aircraft");

  const airportItems = useMemo<ComboboxItem[]>(
    () =>
      airports.map((a) => ({
        value: a.icao,
        label: a.name,
        hint: a.icao,
        sub: `${a.iata ?? "—"} · ${a.city}, ${a.country} · ${a.category}`,
        haystack: `${a.icao} ${a.iata ?? ""} ${a.name} ${a.city} ${a.country}`.toLowerCase(),
      })),
    [airports],
  );
  const aircraftItems = useMemo<ComboboxItem[]>(
    () =>
      aircraft.map((a) => ({
        value: a.id,
        label: `${a.manufacturer} ${a.model}`,
        hint: a.category === "turboprop" ? "TP" : a.category === "regional-jet" ? "RJ" : "NB",
        sub: `${a.passengerCapacity || "cargo"} pax · ${a.maxRangeNm} NM · ${a.cruiseSpeedKt} kt · ${a.cruiseFuelKgPerHour} kg/h`,
        haystack: `${a.manufacturer} ${a.model} ${a.category}`.toLowerCase(),
      })),
    [aircraft],
  );
  const pinnedAirportsDep = useMemo(
    () => recentAirports.map((id) => airportItems.find((i) => i.value === id)).filter(Boolean) as ComboboxItem[],
    [recentAirports, airportItems],
  );
  const pinnedAircraft = useMemo(
    () => recentAircraft.map((id) => aircraftItems.find((i) => i.value === id)).filter(Boolean) as ComboboxItem[],
    [recentAircraft, aircraftItems],
  );

  const analyze = useServerFn(analyzeRouteFn);
  const mutation = useMutation({
    mutationFn: (input: AnalyzeInputT) => analyze({ data: input }),
  });

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    pushRecentAirport(departureIcao);
    pushRecentAirport(destinationIcao);
    pushRecentAircraft(aircraftId);
    mutation.mutate({
      departureIcao,
      destinationIcao,
      aircraftId,
      loadFactor: loadFactor / 100,
      competitorFareEur: fare,
      fuelPriceEurPerKg: fuelPrice,
    });
  };

  const result = mutation.data;
  const fromAirport = airports.find((a) => a.icao === departureIcao);
  const toAirport = airports.find((a) => a.icao === destinationIcao);
  const selectedAircraft = aircraft.find((a) => a.id === aircraftId);

  return (
    <div className="relative min-h-screen">
      <div className="absolute inset-0 hud-grid opacity-30" aria-hidden />
      <div className="relative mx-auto max-w-7xl px-4 py-6 sm:px-6">
        {/* Top bar */}
        <header className="mb-6 grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4 sm:flex sm:flex-wrap sm:justify-between">
          <div className="flex min-w-0 items-center gap-3">
            <div className="grid h-10 w-10 shrink-0 place-items-center rounded-md bg-primary/15 text-primary ring-1 ring-primary/30">
              <Plane className="h-5 w-5" />
            </div>
            <div className="min-w-0">
              <div className="font-mono text-[10px] uppercase tracking-[0.28em] text-muted-foreground">
                Silesian Airways · Route Console
              </div>
              <h1 className="truncate font-display text-xl font-bold text-foreground sm:text-2xl">
                {fromAirport?.icao ?? "----"}{" "}
                <span className="text-primary">→</span>{" "}
                {toAirport?.icao ?? "----"}
              </h1>
            </div>
          </div>
          <Link
            to="/"
            className="inline-flex shrink-0 items-center gap-1.5 rounded-md border border-border bg-surface/40 px-3 py-1.5 font-mono text-xs uppercase tracking-wider text-muted-foreground transition hover:text-foreground"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            Home
          </Link>
        </header>

        {/* Bento layout */}
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
          {/* Input panel — spans full on mobile, 4 cols on desktop */}
          <form
            onSubmit={onSubmit}
            className="lg:col-span-4 lg:row-span-2 flex flex-col gap-4 rounded-xl border border-border bg-card/70 p-5 shadow-[var(--shadow-cockpit)] backdrop-blur"
          >
            <SectionLabel icon={RouteIcon}>Flight Plan</SectionLabel>

            <Field label="Departure">
              <Combobox
                items={airportItems}
                value={departureIcao}
                onChange={setDeparture}
                placeholder="Search airport, ICAO, IATA, city…"
                pinned={pinnedAirportsDep}
                pinnedLabel="Recent airports"
              />
            </Field>

            <Field label="Destination">
              <Combobox
                items={airportItems}
                value={destinationIcao}
                onChange={setDestination}
                placeholder="Search airport, ICAO, IATA, city…"
                pinned={pinnedAirportsDep}
                pinnedLabel="Recent airports"
              />
            </Field>

            <Field label="Aircraft">
              <Combobox
                items={aircraftItems}
                value={aircraftId}
                onChange={setAircraftId}
                placeholder="Search manufacturer or model…"
                pinned={pinnedAircraft}
                pinnedLabel="Recent aircraft"
              />
              {selectedAircraft && (
                <p className="mt-1 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                  Range {selectedAircraft.maxRangeNm} NM · Cruise {selectedAircraft.cruiseSpeedKt} kt
                </p>
              )}
            </Field>

            <SectionLabel icon={Gauge}>Economics</SectionLabel>

            <Field
              label={
                <span className="flex items-baseline justify-between">
                  <span>Load factor</span>
                  <span className="font-mono text-sm text-primary">{loadFactor}%</span>
                </span>
              }
            >
              <input
                type="range"
                min={10}
                max={100}
                step={1}
                value={loadFactor}
                onChange={(e) => setLoadFactor(Number(e.target.value))}
                className="w-full accent-[color:var(--primary)]"
              />
            </Field>

            <div className="grid grid-cols-2 gap-3">
              <Field label="Fare (EUR)">
                <input
                  type="number"
                  min={0}
                  max={10000}
                  step={1}
                  value={fare}
                  onChange={(e) => setFare(Number(e.target.value))}
                  className={inputClass}
                />
              </Field>
              <Field label="Fuel EUR/kg">
                <input
                  type="number"
                  min={0}
                  max={20}
                  step={0.01}
                  value={fuelPrice}
                  onChange={(e) => setFuelPrice(Number(e.target.value))}
                  className={inputClass}
                />
              </Field>
            </div>

            <button
              type="submit"
              disabled={mutation.isPending || departureIcao === destinationIcao}
              className="mt-auto inline-flex items-center justify-center gap-2 rounded-md bg-primary px-4 py-2.5 font-mono text-sm font-medium uppercase tracking-widest text-primary-foreground shadow-[var(--shadow-glow)] transition hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-40"
            >
              <PlayCircle className="h-4 w-4" />
              {mutation.isPending ? "Analyzing…" : "Run Analysis"}
            </button>
            {departureIcao === destinationIcao && (
              <p className="text-xs text-warning">Departure and destination must differ.</p>
            )}
            {mutation.isError && (
              <p className="text-xs text-danger">{(mutation.error as Error).message}</p>
            )}
          </form>

          {/* Results zone */}
          {result ? (
            <Results result={result} />
          ) : (
            <EmptyState className="lg:col-span-8 lg:row-span-2" />
          )}
        </div>
      </div>
    </div>
  );
}

/* ————————————————————————————— UI atoms ————————————————————————————— */

const selectClass =
  "w-full rounded-md border border-border bg-surface/60 px-3 py-2 font-mono text-sm text-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary";
const inputClass = selectClass;

function SectionLabel({
  icon: Icon,
  children,
}: {
  icon: ComponentType<{ className?: string }>;
  children: ReactNode;
}) {
  return (
    <div className="flex items-center gap-2 border-b border-border/60 pb-1.5 font-mono text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
      <Icon className="h-3.5 w-3.5 text-primary" />
      {children}
    </div>
  );
}

function Field({
  label,
  children,
}: {
  label: ReactNode;
  children: ReactNode;
}) {
  return (
    <label className="flex flex-col gap-1.5">
      <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
        {label}
      </span>
      {children}
    </label>
  );
}

function EmptyState({ className = "" }: { className?: string }) {
  return (
    <div
      className={`grid place-items-center rounded-xl border border-dashed border-border bg-card/30 p-12 text-center backdrop-blur ${className}`}
    >
      <div className="max-w-sm space-y-3">
        <div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-primary/10 text-primary ring-1 ring-primary/30">
          <PlayCircle className="h-6 w-6" />
        </div>
        <h2 className="font-display text-lg font-semibold text-foreground">
          Awaiting flight plan
        </h2>
        <p className="text-sm text-muted-foreground">
          Set your route, aircraft, and economic assumptions on the left, then run
          the analysis to see full cost breakdown, profitability score, and
          break-even telemetry.
        </p>
      </div>
    </div>
  );
}

/* ————————————————————————————— Results (bento) ————————————————————————————— */

function Results({ result }: { result: RouteAnalysis }) {
  const { profile, cost, revenue, classification, notes } = result;
  const meta = classificationMeta[classification];

  const costRows = [
    { label: "Fuel", value: cost.fuel },
    { label: "Flight crew", value: cost.flightCrew },
    { label: "Cabin crew", value: cost.cabinCrew },
    { label: "Airframe maint", value: cost.airframeMaintenance },
    { label: "Engine reserve", value: cost.engineReserve },
    { label: "APU maint", value: cost.apuMaintenance },
    { label: "Lease", value: cost.lease },
    { label: "Depreciation", value: cost.depreciation },
    { label: "Insurance", value: cost.insurance },
    { label: "Navigation", value: cost.navigation },
    { label: "Landing", value: cost.landing },
    { label: "Handling", value: cost.handling },
    { label: "Pax service", value: cost.paxService },
    { label: "Security", value: cost.security },
    { label: "Parking", value: cost.parking },
    { label: "Catering", value: cost.catering },
    { label: "Cleaning", value: cost.cleaning },
    { label: "De-icing", value: cost.deicing },
    { label: "Carbon (ETS)", value: cost.carbon },
    { label: "Sales & distrib.", value: cost.salesDistribution },
    { label: "Card fees", value: cost.cardFees },
    { label: "Marketing", value: cost.marketing },
    { label: "Delay reserve", value: cost.delayReserve },
    { label: "Contingency", value: cost.contingency },
    { label: "Admin overhead", value: cost.adminOverhead },
  ]
    .filter((row) => row.value > 0)
    .sort((a, b) => b.value - a.value);

  // For radial gauge: profit margin, clamped 0-100.
  const marginScore = Math.max(0, Math.min(100, (result.marginPct + 0.2) * 250));

  return (
    <>
      {/* Profitability hero card */}
      <div className="lg:col-span-8 rounded-xl border border-border bg-card/70 p-5 shadow-[var(--shadow-cockpit)] backdrop-blur animate-in fade-in slide-in-from-bottom-2 duration-300">
        <div className="grid grid-cols-1 gap-6 md:grid-cols-[auto_1fr]">
          {/* Radial gauge */}
          <div className="relative h-40 w-40 self-center justify-self-center">
            <ResponsiveContainer width="100%" height="100%">
              <RadialBarChart
                innerRadius="72%"
                outerRadius="100%"
                data={[{ name: "score", value: marginScore, fill: meta.token }]}
                startAngle={90}
                endAngle={-270}
              >
                <PolarAngleAxis type="number" domain={[0, 100]} tick={false} />
                <RadialBar background={{ fill: "oklch(0.32 0.07 250 / 60%)" }} dataKey="value" cornerRadius={20} />
              </RadialBarChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 grid place-items-center">
              <div className="text-center">
                <div className={`font-display text-2xl font-bold ${meta.ring}`}>
                  {pct(result.marginPct)}
                </div>
                <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                  Margin
                </div>
              </div>
            </div>
          </div>

          <div className="flex flex-col justify-center gap-3">
            <span
              className={`inline-flex w-fit items-center gap-1.5 rounded-full border px-3 py-1 font-mono text-[10px] uppercase tracking-[0.2em] ${meta.badge}`}
            >
              <span className="h-1.5 w-1.5 rounded-full bg-current" />
              {meta.label}
            </span>
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
              <Stat icon={TrendingUp} label="Profit / flight" value={eur(result.profitEur)} tone={result.profitEur >= 0 ? "success" : "danger"} />
              <Stat icon={Wallet} label="Revenue" value={eur(revenue.total)} />
              <Stat icon={Gauge} label="Total cost" value={eur(cost.total)} />
              <Stat icon={Users} label="Passengers" value={`${revenue.passengers}`} sub={`Cost/pax ${eur(result.costPerPassenger)}`} />
              <Stat icon={Target} label="Break-even LF" value={pct(result.breakEvenLoadFactor)} sub={`Now ${pct(result.request.assumptions.loadFactor)}`} />
              <Stat icon={TrendingUp} label="Suggested fare" value={eur(result.suggestedFareEur)} />
            </div>
          </div>
        </div>
      </div>

      {/* Flight profile */}
      <div className="lg:col-span-4 rounded-xl border border-border bg-card/70 p-5 shadow-[var(--shadow-cockpit)] backdrop-blur animate-in fade-in slide-in-from-bottom-2 duration-300 delay-75">
        <SectionLabel icon={Plane}>Flight Profile</SectionLabel>
        <div className="mt-4 grid grid-cols-2 gap-4">
          <Stat icon={RouteIcon} label="Distance" value={`${profile.distanceKm.toFixed(0)} km`} sub={`${profile.distanceNm.toFixed(0)} NM`} />
          <Stat icon={Clock} label="Block time" value={`${Math.round(profile.blockTimeMinutes)} min`} sub={`Flight ${Math.round(profile.flightTimeMinutes)} min`} />
          <Stat icon={Fuel} label="Block fuel" value={`${profile.totalFuelKg.toFixed(0)} kg`} sub={`Trip ${profile.tripFuelKg.toFixed(0)} · Reserve ${(profile.alternateFuelKg + profile.holdReserveFuelKg).toFixed(0)}`} />
          <Stat icon={Gauge} label="Fuel share" value={pct(cost.fuel / cost.total)} sub="of total cost" />
        </div>
      </div>

      {/* Cost donut */}
      <div className="lg:col-span-5 rounded-xl border border-border bg-card/70 p-5 shadow-[var(--shadow-cockpit)] backdrop-blur animate-in fade-in slide-in-from-bottom-2 duration-300 delay-100">
        <SectionLabel icon={Wallet}>Cost Composition</SectionLabel>
        <div className="mt-4 grid grid-cols-1 items-center gap-3 sm:grid-cols-[160px_1fr]">
          <div className="relative mx-auto h-40 w-40">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={costRows}
                  dataKey="value"
                  nameKey="label"
                  innerRadius={48}
                  outerRadius={70}
                  paddingAngle={1}
                  stroke="none"
                >
                  {costRows.map((_, i) => (
                    <Cell key={i} fill={COST_COLORS[i % COST_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={tooltipStyle}
                  formatter={(v: number) => eur(v)}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="pointer-events-none absolute inset-0 grid place-items-center">
              <div className="text-center">
                <div className="font-display text-lg font-bold text-foreground">
                  {eur(cost.total)}
                </div>
                <div className="font-mono text-[9px] uppercase tracking-widest text-muted-foreground">
                  Total
                </div>
              </div>
            </div>
          </div>
          <ul className="grid grid-cols-2 gap-x-3 gap-y-1.5 text-xs">
            {costRows.slice(0, 8).map((row, i) => (
              <li key={row.label} className="flex items-center justify-between gap-2">
                <span className="flex min-w-0 items-center gap-1.5 text-muted-foreground">
                  <span
                    className="h-2 w-2 shrink-0 rounded-sm"
                    style={{ background: COST_COLORS[i % COST_COLORS.length] }}
                  />
                  <span className="truncate">{row.label}</span>
                </span>
                <span className="font-mono tabular-nums text-foreground">
                  {pct(row.value / cost.total)}
                </span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Cost bars */}
      <div className="lg:col-span-7 rounded-xl border border-border bg-card/70 p-5 shadow-[var(--shadow-cockpit)] backdrop-blur animate-in fade-in slide-in-from-bottom-2 duration-300 delay-150">
        <div className="flex items-center justify-between">
          <SectionLabel icon={Gauge}>Cost Breakdown (EUR)</SectionLabel>
        </div>
        <div className="mt-4 h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={costRows} layout="vertical" margin={{ left: 8, right: 12, top: 4, bottom: 4 }}>
              <XAxis type="number" hide />
              <YAxis
                type="category"
                dataKey="label"
                width={100}
                tick={{ fill: "oklch(0.72 0.03 250)", fontSize: 11, fontFamily: "JetBrains Mono, monospace" }}
                axisLine={false}
                tickLine={false}
              />
              <Tooltip
                cursor={{ fill: "oklch(0.62 0.12 245 / 8%)" }}
                contentStyle={tooltipStyle}
                formatter={(v: number) => eur(v)}
              />
              <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                {costRows.map((_, i) => (
                  <Cell key={i} fill={COST_COLORS[i % COST_COLORS.length]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Notes / warnings */}
      {notes.length > 0 && (
        <div className="lg:col-span-12 rounded-xl border border-warning/40 bg-warning/10 p-4 backdrop-blur animate-in fade-in slide-in-from-bottom-2 duration-300 delay-200">
          <div className="mb-1.5 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.2em] text-warning">
            <AlertTriangle className="h-3.5 w-3.5" />
            Advisories
          </div>
          <ul className="space-y-1 text-sm text-foreground">
            {notes.map((n, i) => (
              <li key={i}>· {n}</li>
            ))}
          </ul>
        </div>
      )}
    </>
  );
}

function Stat({
  icon: Icon,
  label,
  value,
  sub,
  tone,
}: {
  icon: ComponentType<{ className?: string }>;
  label: string;
  value: string;
  sub?: string;
  tone?: "success" | "danger";
}) {
  const toneClass =
    tone === "success" ? "text-success" : tone === "danger" ? "text-danger" : "text-foreground";
  return (
    <div>
      <div className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
        <Icon className="h-3 w-3" />
        {label}
      </div>
      <div className={`mt-1 font-display text-lg font-semibold tabular-nums ${toneClass}`}>
        {value}
      </div>
      {sub && <div className="font-mono text-[10px] text-muted-foreground">{sub}</div>}
    </div>
  );
}

const tooltipStyle: CSSProperties = {
  background: "oklch(0.19 0.06 265)",
  border: "1px solid oklch(0.40 0.05 250 / 60%)",
  borderRadius: 8,
  color: "oklch(0.94 0.01 250)",
  fontFamily: "JetBrains Mono, monospace",
  fontSize: 12,
};
