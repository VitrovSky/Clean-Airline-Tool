import { createFileRoute, Link } from "@tanstack/react-router";
import { queryOptions, useMutation, useSuspenseQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  useMemo,
  useState,
  type FormEvent,
  type ComponentType,
  type ReactNode,
  type Dispatch,
  type SetStateAction,
} from "react";
import {
  ArrowLeft,
  Compass,
  Layers,
  Radar,
  Plus,
  Trash2,
  PlayCircle,
  TrendingUp,
  Users,
  Plane,
  MapPin,
  Activity,
  Award,
  ShieldAlert,
  DollarSign,
} from "lucide-react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Combobox, type ComboboxItem } from "@/components/Combobox";
import { listAircraft, listAirports } from "@/lib/routes.functions";
import {
  discoverRoutesFn,
  planFleetFn,
  type DiscoverInputT,
  type FleetInputT,
} from "@/lib/network.functions";
import type { RouteCandidate, DiscoveryStats } from "@/lib/network/discovery";
import type { FleetPlan } from "@/lib/network/fleet";

const aircraftQuery = queryOptions({ queryKey: ["aircraft"], queryFn: () => listAircraft() });
const airportsQuery = queryOptions({ queryKey: ["airports"], queryFn: () => listAirports() });

export const Route = createFileRoute("/network")({
  head: () => ({
    meta: [
      { title: "Strategic Network Planner — Silesian Airways" },
      {
        name: "description",
        content:
          "AI route discovery, fleet assignment, and competitor intelligence for airline network planners.",
      },
      { property: "og:title", content: "Strategic Network Planner — Silesian Airways" },
      {
        property: "og:description",
        content: "Discover profitable routes, optimise fleet utilisation, decode the competitive landscape.",
      },
    ],
  }),
  loader: async ({ context }) => {
    await Promise.all([
      context.queryClient.ensureQueryData(aircraftQuery),
      context.queryClient.ensureQueryData(airportsQuery),
    ]);
  },
  component: NetworkPage,
});

const eur = (n: number) =>
  new Intl.NumberFormat("en-IE", {
    style: "currency",
    currency: "EUR",
    maximumFractionDigits: 0,
  }).format(n);
const compact = (n: number) =>
  new Intl.NumberFormat("en-IE", { notation: "compact", maximumFractionDigits: 1 }).format(n);
const pct = (n: number) => `${(n * 100).toFixed(1)}%`;

type Tab = "discovery" | "fleet" | "intel";

function NetworkPage() {
  const { data: aircraft } = useSuspenseQuery(aircraftQuery);
  const { data: airports } = useSuspenseQuery(airportsQuery);

  const [tab, setTab] = useState<Tab>("discovery");

  // Shared inputs
  const [baseIcao, setBaseIcao] = useState(
    airports.find((a) => a.icao === "EPKT")?.icao ?? airports[0]?.icao ?? "",
  );
  const [aircraftId, setAircraftId] = useState(aircraft[1]?.id ?? aircraft[0]?.id ?? "");
  const [maxFlightHours, setMaxFlightHours] = useState(4);
  const [maxDistanceNm, setMaxDistanceNm] = useState(1500);
  const [minMarginPct, setMinMarginPct] = useState(-20);

  const airportItems = useMemo<ComboboxItem[]>(
    () =>
      airports.map((a) => ({
        value: a.icao,
        label: a.name,
        hint: a.icao,
        sub: `${a.iata ?? "—"} · ${a.city}, ${a.country}`,
        haystack: `${a.icao} ${a.iata ?? ""} ${a.name} ${a.city} ${a.country}`.toLowerCase(),
      })),
    [airports],
  );
  const aircraftItems = useMemo<ComboboxItem[]>(
    () =>
      aircraft.map((a) => ({
        value: a.id,
        label: `${a.manufacturer} ${a.model}`,
        hint: a.category === "turboprop" ? "TP" : a.category === "regional-jet" ? "RJ" : "NB",
        sub: `${a.passengerCapacity} pax · ${a.maxRangeNm} NM`,
        haystack: `${a.manufacturer} ${a.model} ${a.category}`.toLowerCase(),
      })),
    [aircraft],
  );

  const discover = useServerFn(discoverRoutesFn);
  const discovery = useMutation({
    mutationFn: (input: DiscoverInputT) => discover({ data: input }),
  });

  const runDiscovery = (e?: FormEvent) => {
    e?.preventDefault();
    discovery.mutate({
      baseIcao,
      aircraftId,
      maxFlightHours,
      maxDistanceNm,
      minMarginPct: minMarginPct / 100,
      maxResults: 30,
    });
  };

  // Fleet slots
  const [fleetSlots, setFleetSlots] = useState<
    { id: string; aircraftId: string; count: number }[]
  >(() => [{ id: crypto.randomUUID(), aircraftId: aircraft[1]?.id ?? aircraft[0]?.id ?? "", count: 3 }]);
  const plan = useServerFn(planFleetFn);
  const fleetPlan = useMutation({
    mutationFn: (input: FleetInputT) => plan({ data: input }),
  });
  const runFleetPlan = (e?: FormEvent) => {
    e?.preventDefault();
    fleetPlan.mutate({
      baseIcao,
      fleet: fleetSlots
        .filter((s) => s.aircraftId)
        .map(({ aircraftId, count }) => ({ aircraftId, count })),
      maxFlightHours,
      maxDistanceNm,
    });
  };

  return (
    <div className="relative min-h-screen">
      <div className="absolute inset-0 hud-grid opacity-25" aria-hidden />
      <div className="relative mx-auto max-w-7xl px-4 py-6 sm:px-6">
        <header className="mb-6 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-md bg-primary/15 text-primary ring-1 ring-primary/30">
              <Radar className="h-5 w-5" />
            </div>
            <div>
              <div className="font-mono text-[10px] uppercase tracking-[0.28em] text-muted-foreground">
                Silesian Airways · Strategic Network
              </div>
              <h1 className="font-display text-xl font-bold sm:text-2xl">Network Planner</h1>
            </div>
          </div>
          <Link
            to="/"
            className="inline-flex items-center gap-1.5 rounded-md border border-border bg-surface/40 px-3 py-1.5 font-mono text-xs uppercase tracking-wider text-muted-foreground transition hover:text-foreground"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            Home
          </Link>
        </header>

        {/* Tab bar */}
        <div className="mb-5 inline-flex rounded-lg border border-border bg-card/60 p-1 backdrop-blur">
          <TabButton active={tab === "discovery"} onClick={() => setTab("discovery")} icon={Compass}>
            AI Discovery
          </TabButton>
          <TabButton active={tab === "fleet"} onClick={() => setTab("fleet")} icon={Layers}>
            Fleet Planner
          </TabButton>
          <TabButton active={tab === "intel"} onClick={() => setTab("intel")} icon={ShieldAlert}>
            Competitor Intel
          </TabButton>
        </div>

        {tab === "discovery" && (
          <DiscoveryTab
            airportItems={airportItems}
            aircraftItems={aircraftItems}
            baseIcao={baseIcao}
            setBaseIcao={setBaseIcao}
            aircraftId={aircraftId}
            setAircraftId={setAircraftId}
            maxFlightHours={maxFlightHours}
            setMaxFlightHours={setMaxFlightHours}
            maxDistanceNm={maxDistanceNm}
            setMaxDistanceNm={setMaxDistanceNm}
            minMarginPct={minMarginPct}
            setMinMarginPct={setMinMarginPct}
            onRun={runDiscovery}
            isPending={discovery.isPending}
            error={discovery.error as Error | null}
            results={discovery.data?.candidates}
            stats={discovery.data?.stats}
          />
        )}

        {tab === "fleet" && (
          <FleetTab
            airportItems={airportItems}
            aircraftItems={aircraftItems}
            baseIcao={baseIcao}
            setBaseIcao={setBaseIcao}
            maxFlightHours={maxFlightHours}
            setMaxFlightHours={setMaxFlightHours}
            maxDistanceNm={maxDistanceNm}
            setMaxDistanceNm={setMaxDistanceNm}
            fleetSlots={fleetSlots}
            setFleetSlots={setFleetSlots}
            onRun={runFleetPlan}
            isPending={fleetPlan.isPending}
            error={fleetPlan.error as Error | null}
            plan={fleetPlan.data}
          />
        )}

        {tab === "intel" && (
          <IntelTab
            results={discovery.data?.candidates}
            onRunDiscovery={() => setTab("discovery")}
          />
        )}
      </div>
    </div>
  );
}

/* ————————————————————————————— shared atoms ————————————————————————————— */

function TabButton({
  active,
  onClick,
  icon: Icon,
  children,
}: {
  active: boolean;
  onClick: () => void;
  icon: ComponentType<{ className?: string }>;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`inline-flex items-center gap-2 rounded-md px-3 py-1.5 font-mono text-[11px] uppercase tracking-widest transition ${
        active
          ? "bg-primary text-primary-foreground shadow-[var(--shadow-glow)]"
          : "text-muted-foreground hover:text-foreground"
      }`}
    >
      <Icon className="h-3.5 w-3.5" />
      {children}
    </button>
  );
}

function Field({ label, children }: { label: ReactNode; children: ReactNode }) {
  return (
    <label className="flex flex-col gap-1.5">
      <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">{label}</span>
      {children}
    </label>
  );
}

function DiagStat({
  label,
  value,
  tone,
}: {
  label: string;
  value: number;
  tone?: "ok" | "warn" | "danger";
}) {
  const color =
    tone === "ok"
      ? "text-success"
      : tone === "warn"
        ? "text-warning"
        : tone === "danger"
          ? "text-danger"
          : "text-foreground";
  return (
    <div className="flex flex-col gap-0.5 rounded-md border border-border/60 bg-background/40 px-2 py-1.5">
      <span className="text-[9px] uppercase tracking-wider text-muted-foreground">{label}</span>
      <span className={`text-sm ${color}`}>{value}</span>
    </div>
  );
}

const inputClass =
  "w-full rounded-md border border-border bg-surface/60 px-3 py-2 font-mono text-sm text-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary";

function Kpi({
  icon: Icon,
  label,
  value,
  sub,
}: {
  icon: ComponentType<{ className?: string }>;
  label: string;
  value: string;
  sub?: string;
}) {
  return (
    <div className="rounded-xl border border-border bg-card/70 p-4 backdrop-blur">
      <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
        <Icon className="h-3.5 w-3.5 text-primary" />
        {label}
      </div>
      <div className="mt-2 font-display text-xl font-bold text-foreground">{value}</div>
      {sub && <div className="mt-0.5 text-xs text-muted-foreground">{sub}</div>}
    </div>
  );
}

const RISK_STYLE: Record<RouteCandidate["riskLevel"], string> = {
  low: "bg-success/15 text-success border-success/40",
  medium: "bg-warning/15 text-warning border-warning/40",
  high: "bg-danger/15 text-danger border-danger/40",
};

/* ————————————————————————————— Discovery tab ————————————————————————————— */

function DiscoveryTab(props: {
  airportItems: ComboboxItem[];
  aircraftItems: ComboboxItem[];
  baseIcao: string;
  setBaseIcao: (v: string) => void;
  aircraftId: string;
  setAircraftId: (v: string) => void;
  maxFlightHours: number;
  setMaxFlightHours: (v: number) => void;
  maxDistanceNm: number;
  setMaxDistanceNm: (v: number) => void;
  minMarginPct: number;
  setMinMarginPct: (v: number) => void;
  onRun: (e?: FormEvent) => void;
  isPending: boolean;
  error: Error | null;
  results: RouteCandidate[] | undefined;
  stats?: DiscoveryStats;
}) {
  const {
    airportItems, aircraftItems, baseIcao, setBaseIcao, aircraftId, setAircraftId,
    maxFlightHours, setMaxFlightHours, maxDistanceNm, setMaxDistanceNm,
    minMarginPct, setMinMarginPct, onRun, isPending, error, results, stats,
  } = props;

  const [sortKey, setSortKey] = useState<"profit" | "margin" | "distance" | "risk">("profit");
  const sorted = useMemo(() => {
    if (!results) return [];
    const out = [...results];
    if (sortKey === "profit") out.sort((a, b) => b.annualProfitEur - a.annualProfitEur);
    else if (sortKey === "margin") out.sort((a, b) => b.analysis.marginPct - a.analysis.marginPct);
    else if (sortKey === "distance") out.sort((a, b) => a.analysis.profile.distanceNm - b.analysis.profile.distanceNm);
    else if (sortKey === "risk") out.sort((a, b) => (a.riskLevel === "low" ? -1 : 1));
    return out;
  }, [results, sortKey]);

  const totals = useMemo(() => {
    if (!results) return { profit: 0, revenue: 0, avgMargin: 0, count: 0 };
    const profit = results.reduce((s, r) => s + r.annualProfitEur, 0);
    const revenue = results.reduce((s, r) => s + r.annualRevenueEur, 0);
    const avgMargin =
      results.length === 0 ? 0 : results.reduce((s, r) => s + r.analysis.marginPct, 0) / results.length;
    return { profit, revenue, avgMargin, count: results.length };
  }, [results]);

  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
      <form
        onSubmit={onRun}
        className="lg:col-span-4 flex flex-col gap-4 rounded-xl border border-border bg-card/70 p-5 shadow-[var(--shadow-cockpit)] backdrop-blur"
      >
        <SectionLabel icon={Compass}>Search parameters</SectionLabel>
        <Field label="Base airport">
          <Combobox items={airportItems} value={baseIcao} onChange={setBaseIcao} placeholder="Search base…" />
        </Field>
        <Field label="Aircraft">
          <Combobox items={aircraftItems} value={aircraftId} onChange={setAircraftId} placeholder="Aircraft…" />
        </Field>
        <Field label={<span className="flex justify-between"><span>Max flight time</span><span className="font-mono text-primary">{maxFlightHours} h</span></span>}>
          <input type="range" min={0.5} max={12} step={0.5} value={maxFlightHours} onChange={(e) => setMaxFlightHours(Number(e.target.value))} className="w-full accent-[color:var(--primary)]" />
        </Field>
        <Field label={<span className="flex justify-between"><span>Max distance</span><span className="font-mono text-primary">{maxDistanceNm} NM</span></span>}>
          <input type="range" min={100} max={4000} step={50} value={maxDistanceNm} onChange={(e) => setMaxDistanceNm(Number(e.target.value))} className="w-full accent-[color:var(--primary)]" />
        </Field>
        <Field label={<span className="flex justify-between"><span>Min margin</span><span className="font-mono text-primary">{minMarginPct}%</span></span>}>
          <input type="range" min={-30} max={40} step={1} value={minMarginPct} onChange={(e) => setMinMarginPct(Number(e.target.value))} className="w-full accent-[color:var(--primary)]" />
        </Field>
        <button
          type="submit"
          disabled={isPending || !baseIcao || !aircraftId}
          className="mt-2 inline-flex items-center justify-center gap-2 rounded-md bg-primary px-4 py-2.5 font-mono text-sm uppercase tracking-widest text-primary-foreground shadow-[var(--shadow-glow)] transition hover:brightness-110 disabled:opacity-40"
        >
          <PlayCircle className="h-4 w-4" />
          {isPending ? "Scanning network…" : "Discover routes"}
        </button>
        {error && <p className="text-xs text-danger">{error.message}</p>}
      </form>

      <div className="lg:col-span-8 space-y-4">
        {!results && !isPending && (
          <EmptyPanel
            icon={Radar}
            title="No scan yet"
            body="Pick a base, aircraft, and constraints — we'll evaluate every airport in the database and rank the most profitable routes."
          />
        )}

        {results && (
          <>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <Kpi icon={Radar} label="Candidates" value={String(totals.count)} />
              <Kpi icon={TrendingUp} label="Total annual profit" value={eur(totals.profit)} />
              <Kpi icon={DollarSign} label="Total annual revenue" value={eur(totals.revenue)} />
              <Kpi icon={Activity} label="Average margin" value={pct(totals.avgMargin)} />
            </div>

            {stats && (
              <div className="rounded-xl border border-border bg-card/50 p-4 backdrop-blur">
                <SectionLabel icon={Activity}>Discovery diagnostics</SectionLabel>
                <div className="mt-3 grid grid-cols-2 gap-3 font-mono text-[11px] sm:grid-cols-4 lg:grid-cols-7">
                  <DiagStat label="Total airports" value={stats.totalAirports} />
                  <DiagStat label="Missing data" value={stats.skippedMissingData} tone={stats.skippedMissingData ? "danger" : undefined} />
                  <DiagStat label="Too short (<80 NM)" value={stats.tooShort} />
                  <DiagStat label="Out of range" value={stats.outOfRange} tone="warn" />
                  <DiagStat label="Over flight time" value={stats.overFlightTime} tone="warn" />
                  <DiagStat label="Below min margin" value={stats.belowMinMargin} tone={stats.belowMinMargin ? "warn" : undefined} />
                  <DiagStat label="Final candidates" value={stats.finalCandidates} tone="ok" />
                </div>
                <div className="mt-3 grid grid-cols-1 gap-1 text-[10px] text-muted-foreground sm:grid-cols-3">
                  <span>Aircraft max range: <span className="text-foreground">{stats.aircraftMaxRangeNm} NM</span></span>
                  <span>Effective distance cap: <span className="text-foreground">{stats.effectiveMaxNm.toFixed(0)} NM</span></span>
                  <span>Min-margin filter: <span className="text-foreground">{stats.minMarginPct === null ? "off" : `${(stats.minMarginPct * 100).toFixed(0)}%`}</span></span>
                </div>
                {stats.rejections.length > 0 && (
                  <details className="mt-3">
                    <summary className="cursor-pointer text-[10px] uppercase tracking-widest text-muted-foreground">
                      Sample rejections ({stats.rejections.length})
                    </summary>
                    <ul className="mt-2 max-h-40 overflow-auto rounded-md border border-border/60 bg-background/40 p-2 text-[10px] font-mono text-muted-foreground">
                      {stats.rejections.map((r, i) => (
                        <li key={i}>
                          <span className="text-foreground">{r.icao}</span> — {r.reason}
                          {r.detail ? <span className="text-muted-foreground/80"> ({r.detail})</span> : null}
                        </li>
                      ))}
                    </ul>
                  </details>
                )}
              </div>
            )}

            {results.length > 0 && (
              <div className="rounded-xl border border-border bg-card/70 p-4 backdrop-blur animate-in fade-in slide-in-from-bottom-2 duration-300">
                <div className="mb-2 flex items-center justify-between">
                  <SectionLabel icon={TrendingUp}>Top routes by annual profit</SectionLabel>
                </div>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={results.slice(0, 12).map((r) => ({
                      name: r.to.iata ?? r.to.icao,
                      profit: Math.round(r.annualProfitEur / 1000),
                      margin: r.analysis.marginPct,
                    }))} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.32 0.05 250 / 40%)" />
                      <XAxis dataKey="name" tick={{ fontSize: 10, fontFamily: "monospace" }} stroke="oklch(0.6 0.04 250)" />
                      <YAxis tick={{ fontSize: 10, fontFamily: "monospace" }} stroke="oklch(0.6 0.04 250)" tickFormatter={(v) => `${v}k`} />
                      <Tooltip
                        contentStyle={{ background: "oklch(0.18 0.05 250)", border: "1px solid oklch(0.32 0.07 250)", borderRadius: 8, fontFamily: "monospace", fontSize: 12 }}
                        formatter={(v: number) => [`${v}k EUR`, "Annual profit"]}
                      />
                      <Bar dataKey="profit" radius={[6, 6, 0, 0]}>
                        {results.slice(0, 12).map((r, i) => (
                          <Cell key={i} fill={r.analysis.marginPct >= 0.15 ? "#22c55e" : r.analysis.marginPct >= 0.05 ? "#facc15" : "#ef4444"} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            )}

            <div className="rounded-xl border border-border bg-card/70 backdrop-blur">
              <div className="flex items-center justify-between px-4 py-3">
                <SectionLabel icon={MapPin}>Recommended routes</SectionLabel>
                <select
                  value={sortKey}
                  onChange={(e) => setSortKey(e.target.value as typeof sortKey)}
                  className={inputClass + " max-w-[180px]"}
                >
                  <option value="profit">Sort: Annual profit</option>
                  <option value="margin">Sort: Margin</option>
                  <option value="distance">Sort: Distance</option>
                  <option value="risk">Sort: Risk</option>
                </select>
              </div>
              <div className="max-h-[560px] overflow-auto">
                <table className="w-full border-collapse font-mono text-xs">
                  <thead className="sticky top-0 bg-card/95 backdrop-blur">
                    <tr className="border-b border-border/60 text-[10px] uppercase tracking-widest text-muted-foreground">
                      <th className="px-3 py-2 text-left">Destination</th>
                      <th className="px-3 py-2 text-right">Dist</th>
                      <th className="px-3 py-2 text-right">LF</th>
                      <th className="px-3 py-2 text-right">Margin</th>
                      <th className="px-3 py-2 text-right">Ann. Profit</th>
                      <th className="px-3 py-2 text-center">Risk</th>
                    </tr>
                  </thead>
                  <tbody>
                    {sorted.length === 0 && (
                      <tr><td colSpan={6} className="px-3 py-8 text-center text-muted-foreground">No routes matched your constraints.</td></tr>
                    )}
                    {sorted.map((r) => (
                      <tr key={r.to.icao} className="border-b border-border/30 transition hover:bg-primary/5">
                        <td className="px-3 py-2">
                          <div className="text-foreground">{r.to.iata ?? r.to.icao} · {r.to.city}</div>
                          <div className="text-[10px] text-muted-foreground">{r.to.name}</div>
                        </td>
                        <td className="px-3 py-2 text-right text-foreground">{Math.round(r.analysis.profile.distanceNm)} NM</td>
                        <td className="px-3 py-2 text-right text-foreground">{pct(r.estimatedLoadFactor)}</td>
                        <td className={`px-3 py-2 text-right ${r.analysis.marginPct >= 0.1 ? "text-success" : r.analysis.marginPct >= 0 ? "text-warning" : "text-danger"}`}>{pct(r.analysis.marginPct)}</td>
                        <td className="px-3 py-2 text-right text-foreground">{eur(r.annualProfitEur)}</td>
                        <td className="px-3 py-2 text-center">
                          <span className={`rounded-full border px-2 py-0.5 text-[10px] uppercase ${RISK_STYLE[r.riskLevel]}`}>{r.riskLevel}</span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {sorted.length > 0 && (
              <div className="rounded-xl border border-border bg-card/70 p-4 backdrop-blur">
                <SectionLabel icon={Award}>Why the top pick works</SectionLabel>
                <div className="mt-3 space-y-2 text-sm text-muted-foreground">
                  {sorted.slice(0, 3).map((r) => (
                    <p key={r.to.icao}>
                      <span className="font-mono text-primary">{r.from.icao} → {r.to.icao}</span> · {r.rationale}
                    </p>
                  ))}
                </div>
              </div>
            )}
          </>
        )}

        {isPending && <EmptyPanel icon={Radar} title="Scanning…" body="Analysing hundreds of city pairs." />}
      </div>
    </div>
  );
}

/* ————————————————————————————— Fleet tab ————————————————————————————— */

function FleetTab(props: {
  airportItems: ComboboxItem[];
  aircraftItems: ComboboxItem[];
  baseIcao: string;
  setBaseIcao: (v: string) => void;
  maxFlightHours: number;
  setMaxFlightHours: (v: number) => void;
  maxDistanceNm: number;
  setMaxDistanceNm: (v: number) => void;
  fleetSlots: { id: string; aircraftId: string; count: number }[];
  setFleetSlots: Dispatch<SetStateAction<{ id: string; aircraftId: string; count: number }[]>>;
  onRun: (e?: FormEvent) => void;
  isPending: boolean;
  error: Error | null;
  plan: FleetPlan | undefined;
}) {
  const {
    airportItems, aircraftItems, baseIcao, setBaseIcao,
    maxFlightHours, setMaxFlightHours, maxDistanceNm, setMaxDistanceNm,
    fleetSlots, setFleetSlots, onRun, isPending, error, plan,
  } = props;

  const updateSlot = (id: string, patch: Partial<{ aircraftId: string; count: number }>) => {
    setFleetSlots((prev) => prev.map((s) => (s.id === id ? { ...s, ...patch } : s)));
  };
  const removeSlot = (id: string) => setFleetSlots((prev) => prev.filter((s) => s.id !== id));
  const addSlot = () =>
    setFleetSlots((prev) => [
      ...prev,
      { id: crypto.randomUUID(), aircraftId: aircraftItems[0]?.value ?? "", count: 1 },
    ]);

  const totalAirframes = fleetSlots.reduce((s, r) => s + r.count, 0);

  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
      <form
        onSubmit={onRun}
        className="lg:col-span-4 flex flex-col gap-4 rounded-xl border border-border bg-card/70 p-5 shadow-[var(--shadow-cockpit)] backdrop-blur"
      >
        <SectionLabel icon={Layers}>Fleet composition</SectionLabel>
        <Field label="Base airport">
          <Combobox items={airportItems} value={baseIcao} onChange={setBaseIcao} placeholder="Search base…" />
        </Field>

        <div className="space-y-3">
          {fleetSlots.map((slot, i) => (
            <div key={slot.id} className="rounded-lg border border-border/60 bg-surface/40 p-3">
              <div className="mb-2 flex items-center justify-between">
                <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Type {i + 1}</span>
                {fleetSlots.length > 1 && (
                  <button type="button" onClick={() => removeSlot(slot.id)} className="text-muted-foreground hover:text-danger">
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                )}
              </div>
              <Combobox
                items={aircraftItems}
                value={slot.aircraftId}
                onChange={(v) => updateSlot(slot.id, { aircraftId: v })}
                placeholder="Aircraft type…"
              />
              <div className="mt-2 flex items-center gap-2">
                <span className="font-mono text-[10px] uppercase text-muted-foreground">Airframes</span>
                <input
                  type="number"
                  min={1}
                  max={20}
                  value={slot.count}
                  onChange={(e) => updateSlot(slot.id, { count: Math.max(1, Number(e.target.value)) })}
                  className={inputClass + " w-20"}
                />
              </div>
            </div>
          ))}
          <button
            type="button"
            onClick={addSlot}
            className="inline-flex w-full items-center justify-center gap-1.5 rounded-md border border-dashed border-border py-2 font-mono text-xs uppercase tracking-widest text-muted-foreground transition hover:text-primary"
          >
            <Plus className="h-3.5 w-3.5" /> Add aircraft type
          </button>
        </div>

        <SectionLabel icon={Compass}>Route constraints</SectionLabel>
        <Field label={<span className="flex justify-between"><span>Max flight time</span><span className="font-mono text-primary">{maxFlightHours} h</span></span>}>
          <input type="range" min={0.5} max={12} step={0.5} value={maxFlightHours} onChange={(e) => setMaxFlightHours(Number(e.target.value))} className="w-full accent-[color:var(--primary)]" />
        </Field>
        <Field label={<span className="flex justify-between"><span>Max distance</span><span className="font-mono text-primary">{maxDistanceNm} NM</span></span>}>
          <input type="range" min={100} max={4000} step={50} value={maxDistanceNm} onChange={(e) => setMaxDistanceNm(Number(e.target.value))} className="w-full accent-[color:var(--primary)]" />
        </Field>

        <button
          type="submit"
          disabled={isPending || totalAirframes === 0}
          className="inline-flex items-center justify-center gap-2 rounded-md bg-primary px-4 py-2.5 font-mono text-sm uppercase tracking-widest text-primary-foreground shadow-[var(--shadow-glow)] transition hover:brightness-110 disabled:opacity-40"
        >
          <PlayCircle className="h-4 w-4" />
          {isPending ? "Optimising…" : "Plan fleet"}
        </button>
        {error && <p className="text-xs text-danger">{error.message}</p>}
      </form>

      <div className="lg:col-span-8 space-y-4">
        {!plan && !isPending && (
          <EmptyPanel
            icon={Layers}
            title="No plan yet"
            body="Compose a fleet and let the optimiser assign each airframe to the most profitable routes it can fly, respecting annual utilisation budgets."
          />
        )}

        {plan && (
          <>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <Kpi icon={Plane} label="Airframes" value={String(plan.assignments.length)} />
              <Kpi icon={TrendingUp} label="Annual profit" value={eur(plan.totalAnnualProfitEur)} />
              <Kpi icon={DollarSign} label="Annual revenue" value={eur(plan.totalAnnualRevenueEur)} />
              <Kpi icon={Activity} label="Avg utilisation" value={pct(plan.fleetUtilizationPct)} />
            </div>

            <div className="rounded-xl border border-border bg-card/70 p-4 backdrop-blur">
              <SectionLabel icon={Layers}>Airframe assignments</SectionLabel>
              <div className="mt-3 space-y-3">
                {plan.assignments.map((a) => (
                  <div key={a.tailNumber} className="rounded-lg border border-border/60 bg-surface/40 p-4">
                    <div className="flex flex-wrap items-baseline justify-between gap-2">
                      <div>
                        <div className="font-display text-base font-bold text-foreground">{a.tailNumber}</div>
                        <div className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground">{a.aircraft.manufacturer} {a.aircraft.model}</div>
                      </div>
                      <div className="flex items-baseline gap-4 text-right">
                        <div>
                          <div className="font-mono text-[10px] uppercase text-muted-foreground">Utilisation</div>
                          <div className="font-mono text-sm text-primary">{Math.round(a.blockHoursUsed)} / {a.aircraft.annualUtilizationHours} h · {pct(a.utilizationPct)}</div>
                        </div>
                        <div>
                          <div className="font-mono text-[10px] uppercase text-muted-foreground">Annual profit</div>
                          <div className="font-mono text-sm text-success">{eur(a.annualProfitEur)}</div>
                        </div>
                      </div>
                    </div>
                    <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-surface">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-primary to-success"
                        style={{ width: `${Math.min(100, a.utilizationPct * 100)}%` }}
                      />
                    </div>
                    {a.routes.length === 0 ? (
                      <p className="mt-3 text-xs text-muted-foreground">Idle — no route within constraints was profitable.</p>
                    ) : (
                      <div className="mt-3 flex flex-wrap gap-1.5">
                        {a.routes.map((r) => (
                          <span key={r.to.icao} className="rounded-md border border-border bg-card/60 px-2 py-0.5 font-mono text-[10px] text-foreground">
                            {r.from.iata ?? r.from.icao} → {r.to.iata ?? r.to.icao}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {plan.unassignedRoutes.length > 0 && (
              <div className="rounded-xl border border-warning/30 bg-warning/5 p-4 backdrop-blur">
                <SectionLabel icon={ShieldAlert}>Profitable routes left on the table</SectionLabel>
                <div className="mt-2 flex flex-wrap gap-2">
                  {plan.unassignedRoutes.slice(0, 12).map((r) => (
                    <span key={r.to.icao + r.aircraft.id} className="rounded-md border border-warning/40 bg-card/60 px-2 py-0.5 font-mono text-[11px] text-warning">
                      {r.to.iata ?? r.to.icao} · {eur(r.annualProfitEur)}
                    </span>
                  ))}
                </div>
                <p className="mt-2 text-xs text-muted-foreground">Grow the fleet or raise utilisation caps to capture these.</p>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

/* ————————————————————————————— Intel tab ————————————————————————————— */

const LEVEL_STYLE: Record<string, string> = {
  monopoly: "bg-success/15 text-success border-success/40",
  light: "bg-success/10 text-success border-success/30",
  moderate: "bg-warning/15 text-warning border-warning/40",
  intense: "bg-danger/10 text-danger border-danger/40",
  saturated: "bg-danger/20 text-danger border-danger/50",
};

function IntelTab({
  results,
  onRunDiscovery,
}: {
  results: RouteCandidate[] | undefined;
  onRunDiscovery: () => void;
}) {
  if (!results || results.length === 0) {
    return (
      <EmptyPanel
        icon={ShieldAlert}
        title="Run a discovery scan first"
        body="Competitor intelligence is generated per candidate route. Head to AI Discovery, run a scan, and this tab will populate."
        action={{ label: "Go to AI Discovery", onClick: onRunDiscovery }}
      />
    );
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Kpi icon={Users} label="Routes analysed" value={String(results.length)} />
        <Kpi
          icon={Activity}
          label="Avg competitors / route"
          value={(results.reduce((s, r) => s + r.intel.numCompetitors, 0) / results.length).toFixed(1)}
        />
        <Kpi
          icon={DollarSign}
          label="Avg market fare"
          value={eur(results.reduce((s, r) => s + r.intel.averageFareEur, 0) / results.length)}
        />
        <Kpi
          icon={TrendingUp}
          label="Avg SLS market share"
          value={pct(results.reduce((s, r) => s + r.intel.marketSharePct, 0) / results.length)}
        />
      </div>

      <div className="rounded-xl border border-border bg-card/70 backdrop-blur">
        <div className="border-b border-border/40 px-4 py-3">
          <SectionLabel icon={ShieldAlert}>Route-by-route competitive picture</SectionLabel>
        </div>
        <div className="max-h-[640px] overflow-auto">
          <table className="w-full border-collapse font-mono text-xs">
            <thead className="sticky top-0 bg-card/95 backdrop-blur">
              <tr className="border-b border-border/60 text-[10px] uppercase tracking-widest text-muted-foreground">
                <th className="px-3 py-2 text-left">Route</th>
                <th className="px-3 py-2 text-left">Airlines</th>
                <th className="px-3 py-2 text-right">Freq/day</th>
                <th className="px-3 py-2 text-right">Market size</th>
                <th className="px-3 py-2 text-right">Mkt fare</th>
                <th className="px-3 py-2 text-right">Rec fare</th>
                <th className="px-3 py-2 text-center">Level</th>
                <th className="px-3 py-2 text-right">SLS share</th>
                <th className="px-3 py-2 text-right">Ann. profit</th>
              </tr>
            </thead>
            <tbody>
              {results.map((r) => (
                <tr key={r.to.icao} className="border-b border-border/30 align-top transition hover:bg-primary/5">
                  <td className="px-3 py-2">
                    <div className="text-foreground">{r.from.iata ?? r.from.icao} → {r.to.iata ?? r.to.icao}</div>
                    <div className="text-[10px] text-muted-foreground">{r.to.city}, {r.to.country}</div>
                  </td>
                  <td className="px-3 py-2 text-[11px] text-foreground">
                    {r.intel.competitors.length === 0 ? (
                      <span className="text-muted-foreground">— (no direct competition)</span>
                    ) : (
                      r.intel.competitors.join(", ")
                    )}
                  </td>
                  <td className="px-3 py-2 text-right text-foreground">{r.intel.dailyFrequency}</td>
                  <td className="px-3 py-2 text-right text-foreground">{compact(r.analysis.revenue.passengers * r.dailyFrequency * 340 * 2 / r.intel.marketSharePct)}</td>
                  <td className="px-3 py-2 text-right text-foreground">{eur(r.intel.averageFareEur)}</td>
                  <td className="px-3 py-2 text-right text-primary">{eur(r.intel.recommendedFareEur)}</td>
                  <td className="px-3 py-2 text-center">
                    <span className={`rounded-full border px-2 py-0.5 text-[10px] uppercase ${LEVEL_STYLE[r.intel.competitionLevel]}`}>
                      {r.intel.competitionLevel}
                    </span>
                  </td>
                  <td className="px-3 py-2 text-right text-foreground">{pct(r.intel.marketSharePct)}</td>
                  <td className="px-3 py-2 text-right text-success">{eur(r.annualProfitEur)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="rounded-xl border border-border bg-card/70 p-4 backdrop-blur">
        <SectionLabel icon={Award}>Pricing strategy playbook</SectionLabel>
        <div className="mt-3 grid grid-cols-1 gap-3 md:grid-cols-2">
          {results.slice(0, 6).map((r) => (
            <div key={r.to.icao} className="rounded-lg border border-border/60 bg-surface/40 p-3">
              <div className="flex items-baseline justify-between">
                <div className="font-mono text-sm text-foreground">{r.from.icao} → {r.to.icao}</div>
                <span className={`rounded-full border px-2 py-0.5 font-mono text-[10px] uppercase ${LEVEL_STYLE[r.intel.competitionLevel]}`}>
                  {r.intel.pricingStrategy.replace("-", " ")}
                </span>
              </div>
              <p className="mt-2 text-xs text-muted-foreground">{r.intel.rationale}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ————————————————————————————— empty state ————————————————————————————— */

function SectionLabel({
  icon: Icon,
  children,
}: {
  icon: ComponentType<{ className?: string }>;
  children: ReactNode;
}) {
  return (
    <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
      <Icon className="h-3.5 w-3.5 text-primary" />
      {children}
    </div>
  );
}

function EmptyPanel({
  icon: Icon,
  title,
  body,
  action,
}: {
  icon: ComponentType<{ className?: string }>;
  title: string;
  body: string;
  action?: { label: string; onClick: () => void };
}) {
  return (
    <div className="grid place-items-center rounded-xl border border-dashed border-border bg-card/30 p-12 text-center backdrop-blur">
      <div className="max-w-sm space-y-3">
        <div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-primary/10 text-primary ring-1 ring-primary/30">
          <Icon className="h-6 w-6" />
        </div>
        <h2 className="font-display text-lg font-semibold text-foreground">{title}</h2>
        <p className="text-sm text-muted-foreground">{body}</p>
        {action && (
          <button
            type="button"
            onClick={action.onClick}
            className="inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 font-mono text-xs uppercase tracking-widest text-primary-foreground shadow-[var(--shadow-glow)] transition hover:brightness-110"
          >
            {action.label}
          </button>
        )}
      </div>
    </div>
  );
}