import { createFileRoute, Link } from "@tanstack/react-router";
import { Plane, Gauge, LineChart, MapPin, Radar } from "lucide-react";

export const Route = createFileRoute("/")({
  component: Index,
});

function Index() {
  return (
    <div className="relative min-h-screen overflow-hidden">
      <div className="absolute inset-0 hud-grid opacity-40" aria-hidden />
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-primary/60 to-transparent" aria-hidden />

      <div className="relative mx-auto flex min-h-screen max-w-6xl flex-col px-6 py-10">
        <header className="flex items-center justify-between">
          <div className="flex items-center gap-2 font-mono text-xs uppercase tracking-[0.28em] text-muted-foreground">
            <span className="inline-block h-1.5 w-1.5 animate-pulse rounded-full bg-success" />
            SLS · Ops Console · v0.2
          </div>
          <div className="font-mono text-xs text-muted-foreground">EUR · UTC</div>
        </header>

        <main className="flex flex-1 flex-col items-start justify-center py-16">
          <div className="mb-4 flex items-center gap-3 font-mono text-xs uppercase tracking-[0.28em] text-primary">
            <Plane className="h-3.5 w-3.5" />
            Silesian Airways · Route Economics
          </div>
          <h1 className="max-w-4xl font-display text-5xl font-bold leading-[1.05] tracking-tight text-foreground md:text-6xl">
            Turn every sector into a<br />
            <span className="text-primary">go / no-go</span> decision.
          </h1>
          <p className="mt-6 max-w-2xl text-base text-muted-foreground md:text-lg">
            Route Analyzer models fuel, fees, crew, maintenance and lease across the
            Central-European regional network, then classifies profitability in five tiers —
            so planners commit capacity where the numbers stack up.
          </p>

          <div className="mt-10 flex flex-wrap gap-3">
            <Link
              to="/planner"
              className="group inline-flex items-center gap-2 rounded-md bg-primary px-5 py-3 font-mono text-sm font-medium uppercase tracking-widest text-primary-foreground shadow-[var(--shadow-glow)] transition hover:brightness-110"
            >
              Open Route Planner
              <span className="transition group-hover:translate-x-1">→</span>
            </Link>
            <Link
              to="/network"
              className="group inline-flex items-center gap-2 rounded-md border border-primary/60 bg-primary/10 px-5 py-3 font-mono text-sm font-medium uppercase tracking-widest text-primary transition hover:bg-primary/20"
            >
              <Radar className="h-4 w-4" />
              Strategic Network
            </Link>
            <a
              href="#capabilities"
              className="inline-flex items-center gap-2 rounded-md border border-border bg-surface/40 px-5 py-3 font-mono text-sm uppercase tracking-widest text-foreground backdrop-blur transition hover:bg-surface"
            >
              Capabilities
            </a>
          </div>
        </main>

        <section
          id="capabilities"
          className="grid grid-cols-1 gap-4 pb-10 sm:grid-cols-2 lg:grid-cols-4"
        >
          {[
            { icon: MapPin, label: "542 airports", sub: "Central & Eastern Europe" },
            { icon: Plane, label: "20 aircraft", sub: "Turboprop → widebody" },
            { icon: Gauge, label: "25 cost lines", sub: "Fuel → contingency" },
            { icon: LineChart, label: "5-tier scoring", sub: "Break-even & margin" },
          ].map(({ icon: Icon, label, sub }) => (
            <div
              key={label}
              className="rounded-lg border border-border/60 bg-card/60 p-4 backdrop-blur transition hover:border-primary/60"
            >
              <Icon className="h-4 w-4 text-primary" />
              <div className="mt-3 font-mono text-sm font-medium text-foreground">{label}</div>
              <div className="text-xs text-muted-foreground">{sub}</div>
            </div>
          ))}
        </section>
      </div>
    </div>
  );
}
