# `src/lib` — Application Layers

```
lib/
  calc/     Pure business logic (see calc/README.md). Portable.
  data/     Seed JSON + tiny access helpers. Swap for DB in Step 3.
  server/   TanStack server functions (Step 2). Thin wrappers that read
            the DB and call calc/*. Never contain math.
  reports/  PDF / XLSX / CSV generators (Step 5).
```

Dependency direction (nothing points backwards):

```
UI (routes/*)  →  server/*  →  calc/*  →  types/
                       ↘   data/  ↗
```
