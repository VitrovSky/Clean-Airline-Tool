/**
 * Server functions for the Strategic Network Planner.
 *
 * Thin wrappers: validate input, load data, materialise assumptions from
 * global settings, then delegate to the pure `src/lib/network/*` modules.
 */
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { AIRPORTS, getAirport, getAircraft } from "@/lib/data";
import { SETTINGS } from "@/lib/config";
import { discoverRoutes, type DiscoveryResult } from "@/lib/network/discovery";
import { planFleet, type FleetPlan } from "@/lib/network/fleet";
import type { RouteAssumptions } from "@/types/domain";

function defaultAssumptions(): RouteAssumptions {
  const s = SETTINGS;
  return {
    fuelPriceEurPerKg: s.fuel.priceEurPerKg,
    loadFactor: s.loadFactor.default,
    competitorFareEur: 120,
    targetMarginPct: s.pricing.targetMarginPct,
    eurocontrolUnitRateEur: s.navigation.eurocontrolUnitRateEur,
    navMtowFactor: s.navigation.mtowFactor,
    cockpitCrewEurPerCrewPerBlockHour: s.crew.cockpitEurPerCrewPerBlockHour,
    cabinCrewEurPerCrewPerBlockHour: s.crew.cabinEurPerCrewPerBlockHour,
    cateringEurPerPax: s.cabin.cateringEurPerPax,
    cleaningEurPerFlight: s.cabin.cleaningEurPerFlight,
    isDeicingSeason: false,
    deicingFeeEur: s.airportDefaults.deicingFeeEur,
    co2KgPerFuelKg: s.fuel.co2KgPerFuelKg,
    carbonPriceEurPerTonneCO2: s.fuel.carbonPriceEurPerTonneCO2,
    salesDistributionPctOfRevenue: s.commercial.salesDistributionPctOfRevenue,
    cardFeesPctOfRevenue: s.commercial.cardFeesPctOfRevenue,
    marketingPctOfRevenue: s.commercial.marketingPctOfRevenue,
    ancillaryEurPerPax: s.commercial.ancillaryEurPerPax,
    adminPctOfDirectCost: s.overhead.adminPctOfDirectCost,
    delayReservePctOfDirectCost: s.reserves.delayReservePctOfDirectCost,
    contingencyPctOfVariable: s.reserves.contingencyPctOfVariable,
    securityFeeEurPerPaxDefault: s.airportDefaults.securityFeeEurPerPax,
  };
}

const DiscoverInput = z.object({
  baseIcao: z.string().trim().length(4).toUpperCase(),
  aircraftId: z.string().trim().min(1).max(64),
  maxFlightHours: z.number().min(0.5).max(18),
  maxDistanceNm: z.number().min(100).max(8000),
  minMarginPct: z.number().min(-1).max(1).optional(),
  maxResults: z.number().int().min(5).max(80).optional(),
});
export type DiscoverInputT = z.infer<typeof DiscoverInput>;

export const discoverRoutesFn = createServerFn({ method: "POST" })
  .inputValidator((raw: unknown) => DiscoverInput.parse(raw))
  .handler(async ({ data }): Promise<DiscoveryResult> => {
    const base = getAirport(data.baseIcao);
    const ac = getAircraft(data.aircraftId);
    if (!base) throw new Error(`Unknown base airport: ${data.baseIcao}`);
    if (!ac) throw new Error(`Unknown aircraft: ${data.aircraftId}`);
    const result = discoverRoutes(base, ac, AIRPORTS, defaultAssumptions(), {
      maxFlightHours: data.maxFlightHours,
      maxDistanceNm: data.maxDistanceNm,
      minMarginPct: data.minMarginPct,
      maxResults: data.maxResults ?? 30,
    });
    return result;
  });

const FleetSlotSchema = z.object({
  aircraftId: z.string().trim().min(1).max(64),
  count: z.number().int().min(1).max(20),
});

const FleetInput = z.object({
  baseIcao: z.string().trim().length(4).toUpperCase(),
  fleet: z.array(FleetSlotSchema).min(1).max(10),
  maxFlightHours: z.number().min(0.5).max(18),
  maxDistanceNm: z.number().min(100).max(8000),
});
export type FleetInputT = z.infer<typeof FleetInput>;

export const planFleetFn = createServerFn({ method: "POST" })
  .inputValidator((raw: unknown) => FleetInput.parse(raw))
  .handler(async ({ data }): Promise<FleetPlan> => {
    const base = getAirport(data.baseIcao);
    if (!base) throw new Error(`Unknown base airport: ${data.baseIcao}`);
    return planFleet(
      base,
      data.fleet,
      getAircraft,
      AIRPORTS,
      defaultAssumptions(),
      {
        maxFlightHours: data.maxFlightHours,
        maxDistanceNm: data.maxDistanceNm,
      },
    );
  });