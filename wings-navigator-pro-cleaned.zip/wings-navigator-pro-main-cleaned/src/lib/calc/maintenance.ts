/**
 * Maintenance reserves. Airframe & engine are billed per flight hour (FH);
 * APU maintenance is billed per cycle (one cycle per flight sector).
 */
import type { Aircraft, FlightProfile } from "@/types/domain";

export function airframeMaintenanceCost(profile: FlightProfile, ac: Aircraft): number {
  return (profile.flightTimeMinutes / 60) * ac.airframeMaintEurPerFh;
}

export function engineReserveCost(profile: FlightProfile, ac: Aircraft): number {
  return (profile.flightTimeMinutes / 60) * ac.engineReserveEurPerFh;
}

export function apuMaintenanceCost(ac: Aircraft): number {
  return ac.apuMaintEurPerCycle;
}