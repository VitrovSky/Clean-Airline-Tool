/** Fuel cost = total block fuel × unit price. */
import type { FlightProfile } from "@/types/domain";

export function fuelCost(profile: FlightProfile, priceEurPerKg: number): number {
  return profile.totalFuelKg * priceEurPerKg;
}