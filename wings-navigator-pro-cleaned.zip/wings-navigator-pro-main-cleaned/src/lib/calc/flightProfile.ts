/**
 * Phased flight profile: taxi → climb → cruise → descent → taxi.
 * Fuel is broken down per phase plus contingency, alternate and hold reserve
 * so downstream cost, weather and dispatch modules can reason about each
 * phase independently. Pure function — no I/O, no globals.
 */
import type { Aircraft, Airport, FlightProfile } from "@/types/domain";
import { KM_PER_NM, haversineKm } from "./distance";

export function computeFlightProfile(
  from: Airport,
  to: Airport,
  ac: Aircraft,
): FlightProfile {
  const distanceKm = haversineKm(from.latitude, from.longitude, to.latitude, to.longitude);
  const distanceNm = distanceKm / KM_PER_NM;

  // Ground distance covered during climb/descent (average of climb/cruise
  // TAS × time). Approximation — good enough for cost modelling; a proper
  // BADA-style profile will replace this in Phase C.
  const climbHrs = ac.climbTimeMinutes / 60;
  const descentHrs = ac.descentTimeMinutes / 60;
  const climbDistNm = climbHrs * ((ac.climbSpeedKt + ac.cruiseSpeedKt) / 2);
  const descentDistNm = descentHrs * ((ac.descentSpeedKt + ac.cruiseSpeedKt) / 2);
  const cruiseDistNm = Math.max(0, distanceNm - climbDistNm - descentDistNm);
  const cruiseMinutes = (cruiseDistNm / ac.cruiseSpeedKt) * 60;

  const flightTimeMinutes = ac.climbTimeMinutes + cruiseMinutes + ac.descentTimeMinutes;
  const blockTimeMinutes = ac.taxiOutMinutes + flightTimeMinutes + ac.taxiInMinutes;

  const taxiFuelKg = ac.taxiFuelKg;
  const climbFuelKg = ac.climbFuelKg;
  const cruiseFuelKg = (cruiseMinutes / 60) * ac.cruiseFuelKgPerHour;
  const descentFuelKg = ac.descentFuelKg;
  const tripFuelKg = taxiFuelKg + climbFuelKg + cruiseFuelKg + descentFuelKg;
  const contingencyFuelKg = tripFuelKg * ac.contingencyFuelPct;
  const alternateFuelKg = ac.alternateFuelKg;
  const holdReserveFuelKg = ac.holdReserveFuelKg;
  const totalFuelKg = tripFuelKg + contingencyFuelKg + alternateFuelKg + holdReserveFuelKg;

  return {
    distanceKm,
    distanceNm,
    taxiOutMinutes: ac.taxiOutMinutes,
    climbMinutes: ac.climbTimeMinutes,
    cruiseMinutes,
    descentMinutes: ac.descentTimeMinutes,
    taxiInMinutes: ac.taxiInMinutes,
    flightTimeMinutes,
    blockTimeMinutes,
    taxiFuelKg,
    climbFuelKg,
    cruiseFuelKg,
    descentFuelKg,
    tripFuelKg,
    contingencyFuelKg,
    alternateFuelKg,
    holdReserveFuelKg,
    totalFuelKg,
  };
}