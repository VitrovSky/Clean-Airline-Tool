/** Classify a route by margin & load-factor headroom. Tune thresholds later. */
import type { ProfitabilityClass } from "@/types/domain";

export function classify(marginPct: number, breakEvenLF: number, actualLF: number): ProfitabilityClass {
  const headroom = actualLF - breakEvenLF;
  if (marginPct >= 0.2 && headroom >= 0.15) return "highly-profitable";
  if (marginPct >= 0.08 && headroom >= 0.05) return "profitable";
  if (Math.abs(marginPct) < 0.03) return "break-even";
  if (marginPct < -0.1 || breakEvenLF > 0.95) return "not-recommended";
  return "risky";
}
