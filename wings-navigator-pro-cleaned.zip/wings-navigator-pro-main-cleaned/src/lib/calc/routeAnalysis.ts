/**
 * Route analysis orchestrator.
 *
 * This is the ONLY calc module allowed to compose others. Each cost line is
 * produced by an independently testable calculator; this module wires them
 * together, sums direct/variable/total subtotals, computes reserves,
 * overhead and commercial costs, and delegates classification.
 */
import type {
  Aircraft,
  Airport,
  CostBreakdown,
  RouteAnalysis,
  RouteRequest,
} from "@/types/domain";
import { computeFlightProfile } from "./flightProfile";
import { fuelCost } from "./fuel";
import { flightCrewCost, cabinCrewCost } from "./crew";
import {
  airframeMaintenanceCost,
  engineReserveCost,
  apuMaintenanceCost,
} from "./maintenance";
import {
  leaseAllocation,
  depreciationAllocation,
  insuranceAllocation,
} from "./ownership";
import {
  landingFee,
  parkingFee,
  handlingFee,
  passengerServiceCharge,
  securityFee,
} from "./airportFees";
import { navigationCharge } from "./navigation";
import { cateringCost, cleaningCost, deicingCost } from "./cabinOps";
import { carbonEmissionCost } from "./environmental";
import {
  salesDistributionCost,
  cardFeeCost,
  marketingCost,
} from "./commercial";
import { adminOverheadCost } from "./overhead";
import {
  delayReserveCost,
  contingencyReserveCost,
} from "./reserves";
import {
  breakEvenLoadFactor,
  computeRevenue,
  suggestedFare,
} from "./revenue";
import { classify } from "./classifier";

export function analyzeRoute(
  request: RouteRequest,
  from: Airport,
  to: Airport,
  ac: Aircraft,
): RouteAnalysis {
  const a = request.assumptions;
  const profile = computeFlightProfile(from, to, ac);
  const passengers = Math.round(ac.passengerCapacity * a.loadFactor);

  // — Variable operating cost (scales with the sector) —
  const fuel = fuelCost(profile, a.fuelPriceEurPerKg);
  const navigation = navigationCharge(profile, ac, a.eurocontrolUnitRateEur, a.navMtowFactor);
  const landing = landingFee(to, ac);
  const parking = parkingFee(to, ac);
  const handling = handlingFee(to, ac);
  const paxService = passengerServiceCharge(to, passengers);
  const security = securityFee(to, passengers, a.securityFeeEurPerPaxDefault);
  const catering = cateringCost(passengers, a.cateringEurPerPax);
  const cleaning = cleaningCost(a.cleaningEurPerFlight);
  const deicing = deicingCost(a.isDeicingSeason, a.deicingFeeEur);
  const carbon = carbonEmissionCost(profile, a.co2KgPerFuelKg, a.carbonPriceEurPerTonneCO2);

  // — Crew —
  const flightCrew = flightCrewCost(profile, ac, a.cockpitCrewEurPerCrewPerBlockHour);
  const cabinCrew = cabinCrewCost(profile, ac, a.cabinCrewEurPerCrewPerBlockHour);

  // — Maintenance —
  const airframeMaintenance = airframeMaintenanceCost(profile, ac);
  const engineReserve = engineReserveCost(profile, ac);
  const apuMaintenance = apuMaintenanceCost(ac);

  // — Ownership (mutually exclusive lease/depreciation) —
  const lease = leaseAllocation(profile, ac);
  const depreciation = depreciationAllocation(profile, ac);
  const insurance = insuranceAllocation(profile, ac);

  const variableSubtotal =
    fuel + navigation + landing + parking + handling + paxService + security +
    catering + cleaning + deicing + carbon;

  const directSubtotal =
    variableSubtotal +
    flightCrew + cabinCrew +
    airframeMaintenance + engineReserve + apuMaintenance +
    lease + depreciation + insurance;

  // — Reserves & overhead (independent of revenue) —
  const contingency = contingencyReserveCost(variableSubtotal, a.contingencyPctOfVariable);
  const delayReserve = delayReserveCost(directSubtotal, a.delayReservePctOfDirectCost);
  const adminOverhead = adminOverheadCost(directSubtotal, a.adminPctOfDirectCost);

  // — Revenue → commercial costs (% of revenue) —
  const revenue = computeRevenue(ac, a.competitorFareEur, a);
  const salesDistribution = salesDistributionCost(revenue.total, a.salesDistributionPctOfRevenue);
  const cardFees = cardFeeCost(revenue.total, a.cardFeesPctOfRevenue);
  const marketing = marketingCost(revenue.total, a.marketingPctOfRevenue);

  const total =
    directSubtotal + contingency + delayReserve + adminOverhead +
    salesDistribution + cardFees + marketing;

  const cost: CostBreakdown = {
    fuel,
    flightCrew, cabinCrew,
    airframeMaintenance, engineReserve, apuMaintenance,
    lease, depreciation, insurance,
    landing, parking, handling, paxService, security,
    navigation,
    catering, cleaning, deicing,
    carbon,
    salesDistribution, cardFees, marketing,
    delayReserve, contingency, adminOverhead,
    directSubtotal, variableSubtotal, total,
  };

  const costPerPassenger = passengers > 0 ? total / passengers : 0;
  const beLF = breakEvenLoadFactor(cost, ac, a.competitorFareEur, a.ancillaryEurPerPax);
  const suggested = suggestedFare(cost, passengers, a.ancillaryEurPerPax, a.targetMarginPct);
  const profitEur = revenue.total - total;
  const marginPct = revenue.total > 0 ? profitEur / revenue.total : -1;
  const classification = classify(marginPct, beLF, a.loadFactor);

  const notes: string[] = [];
  if (profile.distanceNm > ac.maxRangeNm) {
    notes.push(
      `Distance ${profile.distanceNm.toFixed(0)} NM exceeds aircraft range ${ac.maxRangeNm} NM.`,
    );
  }
  if (profile.cruiseMinutes <= 0) {
    notes.push(
      "Sector too short for a full climb + cruise + descent profile; results are illustrative only.",
    );
  }
  if (a.loadFactor < beLF) {
    notes.push(
      `Expected load factor ${(a.loadFactor * 100).toFixed(0)}% is below break-even ${(beLF * 100).toFixed(0)}%.`,
    );
  }

  return {
    request,
    profile,
    cost,
    revenue,
    costPerPassenger,
    breakEvenLoadFactor: beLF,
    suggestedFareEur: suggested,
    profitEur,
    marginPct,
    classification,
    notes,
  };
}
