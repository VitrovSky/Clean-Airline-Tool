/**
 * Crew cost per flight. Rates are per-crew-member per block hour, so total
 * cost scales linearly with cockpit/cabin complement declared on the aircraft.
 */
import type { Aircraft, FlightProfile } from "@/types/domain";

export function flightCrewCost(
  profile: FlightProfile,
  ac: Aircraft,
  ratePerCrewPerBlockHour: number,
): number {
  return (profile.blockTimeMinutes / 60) * ratePerCrewPerBlockHour * ac.crewCockpit;
}

export function cabinCrewCost(
  profile: FlightProfile,
  ac: Aircraft,
  ratePerCrewPerBlockHour: number,
): number {
  return (profile.blockTimeMinutes / 60) * ratePerCrewPerBlockHour * ac.crewCabin;
}