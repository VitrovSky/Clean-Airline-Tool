/**
 * Great-circle distance (haversine). Pure function — no I/O, no deps.
 * Flight-profile composition lives in `./flightProfile.ts`; this module
 * only owns the geodesic math so it can be reused by weather segmentation,
 * alternate-airport search, etc.
 */

const EARTH_RADIUS_KM = 6371.0088;
export const KM_PER_NM = 1.852;

export function haversineKm(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number,
): number {
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return 2 * EARTH_RADIUS_KM * Math.asin(Math.sqrt(a));
}
