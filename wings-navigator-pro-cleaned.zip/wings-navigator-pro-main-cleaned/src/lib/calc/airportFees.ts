/**
 * Airport fees. All rates come from the Airport record; where an airport
 * does not publish a value (e.g. security fee) the caller passes an
 * industry-average default from settings.json.
 */
import type { Aircraft, Airport, AircraftCategory } from "@/types/domain";

/** Ground-handling complexity multiplier by aircraft class. */
const HANDLING_CATEGORY_FACTOR: Record<AircraftCategory, number> = {
  turboprop: 1,
  "regional-jet": 1.2,
  narrowbody: 1.5,
  widebody: 2.2,
};

export function landingFee(airport: Airport, ac: Aircraft): number {
  return airport.landingFeeEurPerTonne * ac.mtowTonnes;
}

export function parkingFee(airport: Airport, ac: Aircraft): number {
  return airport.parkingFeeEurPerHour * (ac.turnaroundMinutes / 60);
}

export function handlingFee(airport: Airport, ac: Aircraft): number {
  return airport.handlingFeeEur * (HANDLING_CATEGORY_FACTOR[ac.category] ?? 1);
}

export function passengerServiceCharge(airport: Airport, passengers: number): number {
  return airport.paxServiceChargeEur * passengers;
}

export function securityFee(
  airport: Airport,
  passengers: number,
  defaultEurPerPax: number,
): number {
  const rate = airport.securityFeeEurPerPax ?? defaultEurPerPax;
  return rate * passengers;
}