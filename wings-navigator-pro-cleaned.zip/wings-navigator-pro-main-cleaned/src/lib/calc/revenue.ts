/** Revenue, break-even LF and pricing helpers. Pure functions. */
import type {
  Aircraft,
  CostBreakdown,
  RevenueBreakdown,
  RouteAssumptions,
} from "@/types/domain";

export function computeRevenue(
  ac: Aircraft,
  fareEur: number,
  assumptions: RouteAssumptions,
): RevenueBreakdown {
  const passengers = Math.round(ac.passengerCapacity * assumptions.loadFactor);
  const ticketRevenue = passengers * fareEur;
  const ancillaryRevenue = passengers * assumptions.ancillaryEurPerPax;
  return {
    passengers,
    ticketRevenue,
    ancillaryRevenue,
    total: ticketRevenue + ancillaryRevenue,
  };
}

/**
 * Simplified break-even LF: the seat-load fraction at which
 *   passengers × (fare + ancillary) = total cost.
 * Does not re-solve for revenue-tied commercial costs, so the answer is
 * a slight under-estimate — refined in Phase B.
 */
export function breakEvenLoadFactor(
  totalCost: CostBreakdown,
  ac: Aircraft,
  fareEur: number,
  ancillaryEurPerPax: number,
): number {
  const revPerPax = fareEur + ancillaryEurPerPax;
  if (revPerPax <= 0) return 1;
  return Math.min(1, totalCost.total / (ac.passengerCapacity * revPerPax));
}

export function suggestedFare(
  totalCost: CostBreakdown,
  passengers: number,
  ancillaryEurPerPax: number,
  targetMargin: number,
): number {
  if (passengers <= 0) return 0;
  const costPerPax = totalCost.total / passengers;
  return Math.max(0, costPerPax * (1 + targetMargin) - ancillaryEurPerPax);
}
