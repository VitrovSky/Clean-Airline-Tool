# `lib/calc` — Pure Business Logic

Every module here is a pure TypeScript function: same inputs → same outputs,
no I/O, no framework imports, no globals. This is the layer we would port
line-for-line to Python if the backend ever moves to FastAPI.

| Module              | Responsibility                                  |
| ------------------- | ----------------------------------------------- |
| `distance.ts`       | Haversine + flight-profile (time, fuel burn)    |
| `fees.ts`           | Airport & Eurocontrol-style navigation fees     |
| `operating.ts`      | Crew, maintenance, lease, insurance allocation  |
| `revenue.ts`        | Revenue, break-even LF, suggested fare          |
| `classifier.ts`     | Route profitability classification              |
| `routeAnalysis.ts`  | Orchestrator — the only module that composes    |

## Rules
1. No React, no TanStack, no Supabase, no `fetch` in this folder.
2. All money in EUR; distances stated in field names (`Km`, `Nm`).
3. Deterministic: never read `Date.now()`, `Math.random()`, env vars.
4. Adding a cost line = pure function + field in `CostBreakdown` + sum in `routeAnalysis`.
