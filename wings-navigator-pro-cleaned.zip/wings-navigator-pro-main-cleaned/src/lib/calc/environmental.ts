/**
 * Carbon cost. Jet A-1 burns to ~3.16 kg CO₂ per kg fuel (IPCC / DEFRA).
 * Carbon price default aligns with recent EU-ETS aviation clearing prices;
 * both figures are configurable in settings.json.
 */
import type { FlightProfile } from "@/types/domain";

export function carbonEmissionCost(
  profile: FlightProfile,
  co2KgPerFuelKg: number,
  carbonPriceEurPerTonneCO2: number,
): number {
  const co2Tonnes = (profile.totalFuelKg * co2KgPerFuelKg) / 1000;
  return co2Tonnes * carbonPriceEurPerTonneCO2;
}