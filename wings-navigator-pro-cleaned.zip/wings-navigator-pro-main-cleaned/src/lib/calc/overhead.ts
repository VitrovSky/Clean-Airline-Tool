/** Head-office administrative overhead as a % of direct operating cost. */
export function adminOverheadCost(directCost: number, pct: number): number {
  return directCost * pct;
}