/**
 * Fleet ownership allocation. Two mutually exclusive paths:
 *   - "leased" aircraft: monthly lease amortised over monthly block hours
 *   - "owned" aircraft:  straight-line depreciation over its useful life
 * Insurance is allocated per block hour regardless of ownership mode.
 */
import type { Aircraft, FlightProfile } from "@/types/domain";

export function leaseAllocation(profile: FlightProfile, ac: Aircraft): number {
  if (ac.ownership !== "leased") return 0;
  const monthlyBlockHours = ac.annualUtilizationHours / 12;
  if (monthlyBlockHours <= 0) return 0;
  const eurPerBlockHour = ac.monthlyLeaseEur / monthlyBlockHours;
  return (profile.blockTimeMinutes / 60) * eurPerBlockHour;
}

export function depreciationAllocation(profile: FlightProfile, ac: Aircraft): number {
  if (ac.ownership !== "owned") return 0;
  if (ac.depreciationYears <= 0 || ac.annualUtilizationHours <= 0) return 0;
  const annualDepreciation = ac.purchasePriceEur / ac.depreciationYears;
  const eurPerBlockHour = annualDepreciation / ac.annualUtilizationHours;
  return (profile.blockTimeMinutes / 60) * eurPerBlockHour;
}

export function insuranceAllocation(profile: FlightProfile, ac: Aircraft): number {
  if (ac.annualUtilizationHours <= 0) return 0;
  const eurPerBlockHour = ac.annualInsuranceEur / ac.annualUtilizationHours;
  return (profile.blockTimeMinutes / 60) * eurPerBlockHour;
}