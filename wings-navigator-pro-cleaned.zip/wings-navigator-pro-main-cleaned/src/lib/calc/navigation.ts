/**
 * Eurocontrol-style en-route navigation charge:
 *   fee = unitRate × (distanceKm / 100) × sqrt((MTOW × factor) / 50)
 * Unit rates vary by airspace crossed; here we take a weighted average from
 * settings.json until per-FIR data is added in Phase C.
 */
import type { Aircraft, FlightProfile } from "@/types/domain";

export function navigationCharge(
  profile: FlightProfile,
  ac: Aircraft,
  unitRateEur: number,
  mtowFactor: number,
): number {
  const effectiveMtow = ac.mtowTonnes * mtowFactor;
  return unitRateEur * (profile.distanceKm / 100) * Math.sqrt(effectiveMtow / 50);
}