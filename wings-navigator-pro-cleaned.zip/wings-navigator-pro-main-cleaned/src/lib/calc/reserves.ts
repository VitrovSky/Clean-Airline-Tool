/**
 * Operational reserves.
 *   - Delay reserve: covers EU261 comp, missed connections, hotel/meal —
 *     scaled off direct cost.
 *   - Contingency: unforeseen operational variance, scaled off variable cost.
 */
export function delayReserveCost(directCost: number, pct: number): number {
  return directCost * pct;
}
export function contingencyReserveCost(variableCost: number, pct: number): number {
  return variableCost * pct;
}