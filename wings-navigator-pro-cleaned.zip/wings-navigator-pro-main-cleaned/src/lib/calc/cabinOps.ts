/** Catering, cleaning and (seasonal) de-icing. */
export function cateringCost(passengers: number, eurPerPax: number): number {
  return passengers * eurPerPax;
}

export function cleaningCost(eurPerFlight: number): number {
  return eurPerFlight;
}

export function deicingCost(isSeason: boolean, feeEur: number): number {
  return isSeason ? feeEur : 0;
}