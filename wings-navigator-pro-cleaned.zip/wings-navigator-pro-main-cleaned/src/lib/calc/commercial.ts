/**
 * Revenue-tied commercial costs. Each is a straight percentage of total
 * (ticket + ancillary) revenue — GDS/OTA distribution, card processing,
 * marketing spend.
 */
export function salesDistributionCost(revenue: number, pct: number): number {
  return revenue * pct;
}
export function cardFeeCost(revenue: number, pct: number): number {
  return revenue * pct;
}
export function marketingCost(revenue: number, pct: number): number {
  return revenue * pct;
}