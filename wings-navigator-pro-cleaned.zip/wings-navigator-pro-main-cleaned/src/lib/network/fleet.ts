/**
 * Fleet assignment planner.
 *
 * Greedy: for each fleet type, discover candidate routes from base, then
 * assign them to airframes in profit order until each airframe's annual
 * utilisation budget is exhausted.
 */
import type { Aircraft, Airport, RouteAssumptions } from "@/types/domain";
import { discoverRoutes, type RouteCandidate, type DiscoveryConstraints } from "./discovery";

export interface FleetSlot {
  aircraftId: string;
  count: number;
}

export interface AirframeAssignment {
  tailNumber: string;
  aircraft: Aircraft;
  routes: RouteCandidate[];
  blockHoursUsed: number;
  utilizationPct: number;
  annualProfitEur: number;
  annualRevenueEur: number;
}

export interface FleetPlan {
  assignments: AirframeAssignment[];
  totalAnnualProfitEur: number;
  totalAnnualRevenueEur: number;
  fleetUtilizationPct: number;
  unassignedRoutes: RouteCandidate[];
}

export function planFleet(
  base: Airport,
  fleet: readonly FleetSlot[],
  aircraftById: (id: string) => Aircraft | undefined,
  airports: readonly Airport[],
  baseAssumptions: RouteAssumptions,
  constraints: DiscoveryConstraints,
): FleetPlan {
  const assignments: AirframeAssignment[] = [];
  const allCandidates: RouteCandidate[] = [];

  let tailCounter = 1;
  for (const slot of fleet) {
    const ac = aircraftById(slot.aircraftId);
    if (!ac) continue;

    const { candidates } = discoverRoutes(base, ac, airports, baseAssumptions, {
      ...constraints,
      maxResults: 80,
      minMarginPct: -1,
    });
    allCandidates.push(...candidates);

    for (let i = 0; i < slot.count; i++) {
      const assignment: AirframeAssignment = {
        tailNumber: `SLS-${String(tailCounter).padStart(3, "0")}`,
        aircraft: ac,
        routes: [],
        blockHoursUsed: 0,
        utilizationPct: 0,
        annualProfitEur: 0,
        annualRevenueEur: 0,
      };
      tailCounter++;

      for (const cand of candidates) {
        if (cand.annualProfitEur <= 0) continue;
        // block hours per cycle × cycles/yr
        const blockPerCycle = cand.analysis.profile.blockTimeMinutes / 60;
        const annualCycles = 2 * cand.dailyFrequency * 340;
        const routeBlockHours = blockPerCycle * annualCycles;
        if (assignment.blockHoursUsed + routeBlockHours > ac.annualUtilizationHours) continue;
        assignment.routes.push(cand);
        assignment.blockHoursUsed += routeBlockHours;
        assignment.annualProfitEur += cand.annualProfitEur;
        assignment.annualRevenueEur += cand.annualRevenueEur;
      }

      // Remove the routes we just consumed so the next airframe gets fresh work.
      for (const used of assignment.routes) {
        const idx = candidates.indexOf(used);
        if (idx >= 0) candidates.splice(idx, 1);
      }

      assignment.utilizationPct = assignment.blockHoursUsed / ac.annualUtilizationHours;
      assignments.push(assignment);
    }
  }

  const totalAnnualProfitEur = assignments.reduce((s, a) => s + a.annualProfitEur, 0);
  const totalAnnualRevenueEur = assignments.reduce((s, a) => s + a.annualRevenueEur, 0);
  const fleetUtilizationPct =
    assignments.length === 0
      ? 0
      : assignments.reduce((s, a) => s + a.utilizationPct, 0) / assignments.length;

  // Anything left over across all fleets that was profitable but didn't fit.
  const taken = new Set(assignments.flatMap((a) => a.routes.map((r) => r.to.icao + "/" + r.aircraft.id)));
  const unassignedRoutes = allCandidates.filter(
    (c) => c.annualProfitEur > 0 && !taken.has(c.to.icao + "/" + c.aircraft.id),
  );

  return {
    assignments,
    totalAnnualProfitEur,
    totalAnnualRevenueEur,
    fleetUtilizationPct,
    unassignedRoutes: unassignedRoutes.slice(0, 20),
  };
}