/**
 * AI Route Discovery orchestrator.
 *
 * Iterates every airport in the database, filters by aircraft range and
 * user-supplied flight-time / distance caps, then runs the standard
 * `analyzeRoute` calc against a demand-driven load factor and market-
 * derived competitive fare. Returns candidates sorted by annual profit.
 *
 * Pure module — no I/O. Data lookup and settings materialisation happen
 * in the server-function caller.
 */
import type {
  Aircraft,
  Airport,
  RouteAnalysis,
  RouteAssumptions,
} from "@/types/domain";
import { analyzeRoute } from "@/lib/calc/routeAnalysis";
import { haversineKm, KM_PER_NM } from "@/lib/calc/distance";
import { estimateDemand, estimateLoadFactor, recommendedFrequency } from "./demand";
import { estimateCompetition, type CompetitorIntel } from "./competition";

export interface DiscoveryConstraints {
  maxFlightHours: number;
  maxDistanceNm: number;
  minMarginPct?: number;
  maxResults?: number;
}

export interface RouteCandidate {
  from: Airport;
  to: Airport;
  aircraft: Aircraft;
  analysis: RouteAnalysis;
  intel: CompetitorIntel;
  dailyFrequency: number;
  estimatedLoadFactor: number;
  annualProfitEur: number;
  annualRevenueEur: number;
  riskLevel: "low" | "medium" | "high";
  rationale: string;
}

export interface DiscoveryStats {
  totalAirports: number;
  sameAirport: number;
  skippedMissingData: number;
  outOfRange: number;
  overFlightTime: number;
  tooShort: number;
  analysisFailed: number;
  belowMinMargin: number;
  finalCandidates: number;
  aircraftMaxRangeNm: number;
  effectiveMaxNm: number;
  effectiveMaxHours: number;
  minMarginPct: number | null;
  rejections: Array<{ icao: string; reason: string; detail?: string }>;
}

export interface DiscoveryResult {
  candidates: RouteCandidate[];
  stats: DiscoveryStats;
}

export function discoverRoutes(
  base: Airport,
  ac: Aircraft,
  airports: readonly Airport[],
  baseAssumptions: RouteAssumptions,
  constraints: DiscoveryConstraints,
): DiscoveryResult {
  const results: RouteCandidate[] = [];
  const stats: DiscoveryStats = {
    totalAirports: airports.length,
    sameAirport: 0,
    skippedMissingData: 0,
    outOfRange: 0,
    overFlightTime: 0,
    tooShort: 0,
    analysisFailed: 0,
    belowMinMargin: 0,
    finalCandidates: 0,
    aircraftMaxRangeNm: ac.maxRangeNm,
    effectiveMaxNm: Math.min(constraints.maxDistanceNm, ac.maxRangeNm * 0.95),
    effectiveMaxHours: constraints.maxFlightHours,
    minMarginPct: constraints.minMarginPct ?? null,
    rejections: [],
  };
  const logReject = (icao: string, reason: string, detail?: string) => {
    if (stats.rejections.length < 40) stats.rejections.push({ icao, reason, detail });
  };
  const maxNm = Math.min(constraints.maxDistanceNm, ac.maxRangeNm * 0.95);
  const cruiseHours = constraints.maxFlightHours;

  for (const to of airports) {
    if (to.icao === base.icao) { stats.sameAirport++; continue; }
    if (
      !to.icao ||
      typeof to.latitude !== "number" || Number.isNaN(to.latitude) ||
      typeof to.longitude !== "number" || Number.isNaN(to.longitude)
    ) {
      stats.skippedMissingData++;
      logReject(to.icao ?? "UNKNOWN", "missing-data");
      continue;
    }
    const km = haversineKm(base.latitude, base.longitude, to.latitude, to.longitude);
    const nm = km / KM_PER_NM;
    if (nm < 80) {
      stats.tooShort++;
      logReject(to.icao, "too-short", `${nm.toFixed(0)} NM < 80`);
      continue;
    }
    if (nm > maxNm) {
      stats.outOfRange++;
      logReject(to.icao, "out-of-range", `${nm.toFixed(0)} NM > ${maxNm.toFixed(0)}`);
      continue;
    }
    // Rough block time filter (before running full calc).
    const approxHours =
      (ac.taxiOutMinutes + ac.taxiInMinutes + ac.climbTimeMinutes + ac.descentTimeMinutes) / 60 +
      nm / ac.cruiseSpeedKt;
    if (approxHours > cruiseHours) {
      stats.overFlightTime++;
      logReject(to.icao, "over-flight-time", `${approxHours.toFixed(2)} h > ${cruiseHours} h`);
      continue;
    }

    const demand = estimateDemand(base, to);
    const intel = estimateCompetition(base, to, demand);
    const frequency = recommendedFrequency(demand, ac, intel.marketSharePct);
    const lf = estimateLoadFactor(demand, ac, frequency, intel.marketSharePct);

    const assumptions: RouteAssumptions = {
      ...baseAssumptions,
      loadFactor: lf,
      competitorFareEur: intel.recommendedFareEur,
    };

    let analysis: RouteAnalysis;
    try {
      analysis = analyzeRoute(
        {
          departureIcao: base.icao,
          destinationIcao: to.icao,
          aircraftId: ac.id,
          assumptions,
        },
        base,
        to,
        ac,
      );
    } catch (err) {
      stats.analysisFailed++;
      logReject(to.icao, "analysis-failed", (err as Error)?.message);
      continue;
    }

    if (
      constraints.minMarginPct !== undefined &&
      analysis.marginPct < constraints.minMarginPct
    ) {
      stats.belowMinMargin++;
      logReject(
        to.icao,
        "below-min-margin",
        `${(analysis.marginPct * 100).toFixed(1)}% < ${(constraints.minMarginPct * 100).toFixed(1)}%`,
      );
      continue;
    }

    // Annualise: 2 (round trip) × frequency × 340 op days.
    const annualCycles = 2 * frequency * 340;
    const annualRevenueEur = analysis.revenue.total * annualCycles;
    const annualProfitEur = analysis.profitEur * annualCycles;

    const riskLevel: RouteCandidate["riskLevel"] =
      analysis.marginPct >= 0.15 && intel.numCompetitors <= 2
        ? "low"
        : analysis.marginPct >= 0.05
          ? "medium"
          : "high";

    const rationale =
      analysis.marginPct >= 0.15
        ? `Strong ${(analysis.marginPct * 100).toFixed(0)}% margin with ${intel.competitionLevel} competition and ${demand.segmentSize} demand (${demand.annualPax.toLocaleString()} pax/yr).`
        : analysis.marginPct >= 0.05
          ? `Workable margin; ${intel.competitionLevel} competition means execution discipline is required.`
          : `Marginal economics — only viable as feeder / brand play.`;

    results.push({
      from: base,
      to,
      aircraft: ac,
      analysis,
      intel,
      dailyFrequency: frequency,
      estimatedLoadFactor: lf,
      annualRevenueEur,
      annualProfitEur,
      riskLevel,
      rationale,
    });
  }

  results.sort((a, b) => b.annualProfitEur - a.annualProfitEur);
  const trimmed = results.slice(0, constraints.maxResults ?? 40);
  stats.finalCandidates = trimmed.length;
  return { candidates: trimmed, stats };
}