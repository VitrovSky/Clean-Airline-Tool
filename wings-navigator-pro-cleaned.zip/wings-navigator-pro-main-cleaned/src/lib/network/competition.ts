/**
 * Competitor intelligence heuristics.
 *
 * We don't have live schedule data, so we estimate competitor pressure
 * from airport categories, distance, and demand. Deterministic — same
 * inputs always produce the same output — so the dashboard is stable.
 */
import type { Airport } from "@/types/domain";
import type { DemandEstimate } from "./demand";

const EU_MAJORS = [
  "Lufthansa",
  "Ryanair",
  "Wizz Air",
  "easyJet",
  "LOT Polish Airlines",
  "KLM",
  "Air France",
  "SAS",
  "British Airways",
  "Turkish Airlines",
  "ITA Airways",
  "Austrian Airlines",
  "airBaltic",
  "Vueling",
  "TAP Air Portugal",
];

function seededPick<T>(arr: readonly T[], seed: number, count: number): T[] {
  const out: T[] = [];
  let s = seed;
  const used = new Set<number>();
  while (out.length < count && used.size < arr.length) {
    s = (s * 9301 + 49297) % 233280;
    const idx = Math.floor((s / 233280) * arr.length);
    if (!used.has(idx)) {
      used.add(idx);
      out.push(arr[idx]);
    }
  }
  return out;
}

function hash(s: string): number {
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0;
  return Math.abs(h);
}

export type CompetitionLevel = "monopoly" | "light" | "moderate" | "intense" | "saturated";
export type PricingStrategy =
  | "premium"
  | "match-market"
  | "undercut"
  | "value-lead"
  | "stimulate-demand";

export interface CompetitorIntel {
  competitors: string[];
  numCompetitors: number;
  competitionLevel: CompetitionLevel;
  dailyFrequency: number;
  averageFareEur: number;
  marketSharePct: number;
  recommendedFareEur: number;
  pricingStrategy: PricingStrategy;
  rationale: string;
}

export function estimateCompetition(
  from: Airport,
  to: Airport,
  demand: DemandEstimate,
): CompetitorIntel {
  const num = Math.max(
    0,
    Math.min(
      6,
      Math.round(demand.annualPax / 220_000) +
        (from.category === "major-hub" && to.category === "major-hub" ? 1 : 0),
    ),
  );
  const seed = hash(`${from.icao}-${to.icao}`);
  const competitors = seededPick(EU_MAJORS, seed, num);

  const dailyFrequency = num * 1.6 + (demand.segmentSize === "trunk" ? 2 : 0.5);
  const averageFareEur = 55 + demand.distanceNm * 0.09;

  const level: CompetitionLevel =
    num === 0 ? "monopoly" :
    num === 1 ? "light" :
    num <= 3 ? "moderate" :
    num <= 5 ? "intense" : "saturated";

  const marketSharePct =
    num === 0 ? 0.6 :
    Math.max(0.06, 0.55 / (num + 1));

  let strategy: PricingStrategy;
  let recommendedFareEur: number;
  let rationale: string;
  switch (level) {
    case "monopoly":
      strategy = "premium";
      recommendedFareEur = averageFareEur * 1.15;
      rationale = "No direct competition — premium pricing supported by absence of alternatives.";
      break;
    case "light":
      strategy = "match-market";
      recommendedFareEur = averageFareEur * 1.02;
      rationale = "One incumbent — parity pricing wins share on service quality.";
      break;
    case "moderate":
      strategy = "value-lead";
      recommendedFareEur = averageFareEur * 0.96;
      rationale = "Fragmented market — modest discount plus schedule reliability captures share.";
      break;
    case "intense":
      strategy = "undercut";
      recommendedFareEur = averageFareEur * 0.9;
      rationale = "Dense competition — undercut fares and ancillaries drive load.";
      break;
    case "saturated":
      strategy = "stimulate-demand";
      recommendedFareEur = averageFareEur * 0.82;
      rationale = "Saturated corridor — only aggressive pricing plus network feed makes economic sense.";
      break;
  }
  return {
    competitors,
    numCompetitors: num,
    competitionLevel: level,
    dailyFrequency: Math.round(dailyFrequency * 10) / 10,
    averageFareEur: Math.round(averageFareEur),
    marketSharePct,
    recommendedFareEur: Math.round(recommendedFareEur),
    pricingStrategy: strategy,
    rationale,
  };
}