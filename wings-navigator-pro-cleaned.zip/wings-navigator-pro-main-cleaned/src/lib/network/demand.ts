/**
 * Passenger demand & load-factor estimation heuristics.
 *
 * Pure functions. Deliberately transparent: every factor is a named
 * constant so the model can be tuned without touching call sites.
 */
import type { Airport, Aircraft, AirportCategory } from "@/types/domain";
import { haversineKm, KM_PER_NM } from "@/lib/calc/distance";

const CATEGORY_WEIGHT: Record<AirportCategory, number> = {
  "major-hub": 1.0,
  regional: 0.45,
  secondary: 0.2,
  small: 0.07,
};

/** Cross-border country pairs get a small VFR/tourism uplift. */
const CROSS_BORDER_UPLIFT = 1.1;

/** Bell-shaped distance appetite: peaks in the 500-1500 NM sweet spot. */
function distanceAppetite(distanceNm: number): number {
  if (distanceNm < 100) return 0.15;
  if (distanceNm > 3500) return 0.1;
  const peak = 900;
  const width = 900;
  const z = (distanceNm - peak) / width;
  return Math.max(0.2, Math.exp(-0.5 * z * z));
}

export interface DemandEstimate {
  annualPax: number;
  dailyPax: number;
  distanceNm: number;
  distanceFactor: number;
  crossBorder: boolean;
  segmentSize: "thin" | "medium" | "trunk";
}

export function estimateDemand(from: Airport, to: Airport): DemandEstimate {
  const km = haversineKm(from.latitude, from.longitude, to.latitude, to.longitude);
  const distanceNm = km / KM_PER_NM;
  const base = 700_000; // reference annual pax for a major-hub↔major-hub trunk
  const catFactor = CATEGORY_WEIGHT[from.category] * CATEGORY_WEIGHT[to.category];
  const distanceFactor = distanceAppetite(distanceNm);
  const crossBorder = from.country !== to.country;
  const uplift = crossBorder ? CROSS_BORDER_UPLIFT : 1;
  const annualPax = Math.round(base * catFactor * distanceFactor * uplift);
  const dailyPax = annualPax / 365;
  const segmentSize: DemandEstimate["segmentSize"] =
    annualPax > 250_000 ? "trunk" : annualPax > 60_000 ? "medium" : "thin";
  return { annualPax, dailyPax, distanceNm, distanceFactor, crossBorder, segmentSize };
}

/**
 * Estimate the achievable load factor for one aircraft flying this route
 * `dailyFrequency` times per day (each direction).
 */
export function estimateLoadFactor(
  demand: DemandEstimate,
  ac: Aircraft,
  dailyFrequency: number,
  marketSharePct: number,
): number {
  const offeredAnnualSeats = ac.passengerCapacity * dailyFrequency * 2 * 340; // 340 op days
  if (offeredAnnualSeats <= 0) return 0;
  const capturablePax = demand.annualPax * 2 * marketSharePct; // both directions
  const lf = capturablePax / offeredAnnualSeats;
  return Math.max(0.25, Math.min(0.92, lf));
}

/** Recommended daily round-trip frequency given demand and aircraft size. */
export function recommendedFrequency(
  demand: DemandEstimate,
  ac: Aircraft,
  marketSharePct: number = 1,
): number {
  // Only the share we can actually capture drives our schedule;
  // sizing to total-market demand overloads capacity and collapses LF.
  const capturablePax = demand.annualPax * marketSharePct;
  const target = capturablePax / (ac.passengerCapacity * 340 * 0.72); // 72% target LF
  return Math.max(1, Math.min(6, Math.round(target)));
}