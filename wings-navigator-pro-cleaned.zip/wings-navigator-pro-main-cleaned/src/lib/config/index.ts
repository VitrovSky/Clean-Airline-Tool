/**
 * Configuration accessor. All operational assumptions live in settings.json
 * so they can be edited without touching source code. In a later phase this
 * can be swapped for a database-backed loader (Lovable Cloud) without any
 * change to the calc layer — the shape is what matters.
 */
import raw from "./settings.json";
import type { AppSettings } from "@/types/domain";

export const SETTINGS: AppSettings = raw as AppSettings;

export function getSettings(): AppSettings {
  return SETTINGS;
}