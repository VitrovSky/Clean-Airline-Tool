/**
 * Data-access layer for seed JSON.
 *
 * Deliberately thin: swap this file for a Postgres/Lovable Cloud reader
 * later without touching calculators. All defaults live in
 * `src/lib/config/settings.json` (see `@/lib/config`).
 */
import aircraftJson from "./aircraft.json";
import airportsJson from "./airports.json";
import type { Aircraft, Airport } from "@/types/domain";

export const AIRCRAFT: readonly Aircraft[] = aircraftJson as Aircraft[];
export const AIRPORTS: readonly Airport[] = airportsJson as Airport[];

export function getAircraft(id: string): Aircraft | undefined {
  return AIRCRAFT.find((a) => a.id === id);
}

export function getAirport(icao: string): Airport | undefined {
  return AIRPORTS.find((a) => a.icao === icao.toUpperCase());
}
