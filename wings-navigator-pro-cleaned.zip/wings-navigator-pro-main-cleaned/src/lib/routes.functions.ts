/**
 * Server functions for the Route Analyzer.
 * Thin wrappers — validation + data lookup + delegation to lib/calc.
 * No business math lives here.
 */
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { AIRCRAFT, AIRPORTS, getAircraft, getAirport } from "@/lib/data";
import { SETTINGS } from "@/lib/config";
import { analyzeRoute } from "@/lib/calc/routeAnalysis";
import type {
  Aircraft,
  Airport,
  RouteAnalysis,
  RouteAssumptions,
} from "@/types/domain";

export const listAircraft = createServerFn({ method: "GET" }).handler(
  async (): Promise<readonly Aircraft[]> => AIRCRAFT,
);

export const listAirports = createServerFn({ method: "GET" }).handler(
  async (): Promise<readonly Airport[]> => AIRPORTS,
);

const AnalyzeInput = z.object({
  departureIcao: z.string().trim().length(4).toUpperCase(),
  destinationIcao: z.string().trim().length(4).toUpperCase(),
  aircraftId: z.string().trim().min(1).max(64),
  loadFactor: z.number().min(0).max(1),
  competitorFareEur: z.number().min(0).max(10000),
  fuelPriceEurPerKg: z.number().min(0).max(20).optional(),
  isDeicingSeason: z.boolean().optional(),
});
export type AnalyzeInputT = z.infer<typeof AnalyzeInput>;

/**
 * Merge global settings with per-request user overrides into a fully
 * materialised RouteAssumptions record. Calculators never touch settings
 * directly — this is the single conversion point.
 */
function materializeAssumptions(overrides: {
  loadFactor: number;
  competitorFareEur: number;
  fuelPriceEurPerKg?: number;
  isDeicingSeason?: boolean;
}): RouteAssumptions {
  const s = SETTINGS;
  return {
    fuelPriceEurPerKg: overrides.fuelPriceEurPerKg ?? s.fuel.priceEurPerKg,
    loadFactor: overrides.loadFactor,
    competitorFareEur: overrides.competitorFareEur,
    targetMarginPct: s.pricing.targetMarginPct,

    eurocontrolUnitRateEur: s.navigation.eurocontrolUnitRateEur,
    navMtowFactor: s.navigation.mtowFactor,

    cockpitCrewEurPerCrewPerBlockHour: s.crew.cockpitEurPerCrewPerBlockHour,
    cabinCrewEurPerCrewPerBlockHour: s.crew.cabinEurPerCrewPerBlockHour,

    cateringEurPerPax: s.cabin.cateringEurPerPax,
    cleaningEurPerFlight: s.cabin.cleaningEurPerFlight,
    isDeicingSeason: overrides.isDeicingSeason ?? false,
    deicingFeeEur: s.airportDefaults.deicingFeeEur,

    co2KgPerFuelKg: s.fuel.co2KgPerFuelKg,
    carbonPriceEurPerTonneCO2: s.fuel.carbonPriceEurPerTonneCO2,

    salesDistributionPctOfRevenue: s.commercial.salesDistributionPctOfRevenue,
    cardFeesPctOfRevenue: s.commercial.cardFeesPctOfRevenue,
    marketingPctOfRevenue: s.commercial.marketingPctOfRevenue,
    ancillaryEurPerPax: s.commercial.ancillaryEurPerPax,

    adminPctOfDirectCost: s.overhead.adminPctOfDirectCost,

    delayReservePctOfDirectCost: s.reserves.delayReservePctOfDirectCost,
    contingencyPctOfVariable: s.reserves.contingencyPctOfVariable,

    securityFeeEurPerPaxDefault: s.airportDefaults.securityFeeEurPerPax,
  };
}

export const analyzeRouteFn = createServerFn({ method: "POST" })
  .inputValidator((raw: unknown) => AnalyzeInput.parse(raw))
  .handler(async ({ data }): Promise<RouteAnalysis> => {
    if (data.departureIcao === data.destinationIcao) {
      throw new Error("Departure and destination must differ.");
    }
    const from = getAirport(data.departureIcao);
    const to = getAirport(data.destinationIcao);
    const ac = getAircraft(data.aircraftId);
    if (!from) throw new Error(`Unknown departure airport: ${data.departureIcao}`);
    if (!to) throw new Error(`Unknown destination airport: ${data.destinationIcao}`);
    if (!ac) throw new Error(`Unknown aircraft: ${data.aircraftId}`);

    const assumptions = materializeAssumptions(data);
    return analyzeRoute(
      {
        departureIcao: from.icao,
        destinationIcao: to.icao,
        aircraftId: ac.id,
        assumptions,
      },
      from,
      to,
      ac,
    );
  });
