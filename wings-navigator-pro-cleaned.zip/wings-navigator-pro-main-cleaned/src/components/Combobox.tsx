import { useEffect, useId, useMemo, useRef, useState, type KeyboardEvent } from "react";
import { ChevronDown, Search, X } from "lucide-react";

export interface ComboboxItem {
  value: string;
  label: string;
  sub?: string;
  hint?: string;
  /** All searchable strings (lowercased once by parent). */
  haystack: string;
}

interface Props {
  items: readonly ComboboxItem[];
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  emptyLabel?: string;
  maxResults?: number;
  /** Optional pinned items shown when input is empty (favorites/recent). */
  pinned?: readonly ComboboxItem[];
  pinnedLabel?: string;
}

/**
 * Lightweight typeahead combobox — no external deps.
 * O(n) prefix+substring scan capped by `maxResults` (default 50).
 */
export function Combobox({
  items,
  value,
  onChange,
  placeholder = "Search…",
  emptyLabel = "No matches.",
  maxResults = 50,
  pinned,
  pinnedLabel = "Recent",
}: Props) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [active, setActive] = useState(0);
  const rootRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLUListElement>(null);
  const listboxId = useId();

  const selected = useMemo(
    () => items.find((i) => i.value === value),
    [items, value],
  );

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) {
      if (pinned && pinned.length) return pinned.slice(0, maxResults);
      return items.slice(0, maxResults);
    }
    const tokens = q.split(/\s+/).filter(Boolean);
    const scored: Array<{ item: ComboboxItem; score: number }> = [];
    for (const it of items) {
      let score = 0;
      let ok = true;
      for (const t of tokens) {
        const idx = it.haystack.indexOf(t);
        if (idx < 0) {
          ok = false;
          break;
        }
        score += idx === 0 ? 3 : idx < 8 ? 2 : 1;
      }
      if (ok) scored.push({ item: it, score });
      if (scored.length > maxResults * 4) break;
    }
    scored.sort((a, b) => b.score - a.score);
    return scored.slice(0, maxResults).map((s) => s.item);
  }, [items, query, maxResults, pinned]);

  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => {
      if (!rootRef.current?.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, [open]);

  useEffect(() => {
    setActive(0);
  }, [query, open]);

  useEffect(() => {
    if (!open) return;
    const el = listRef.current?.children[active] as HTMLElement | undefined;
    el?.scrollIntoView({ block: "nearest" });
  }, [active, open]);

  const commit = (item: ComboboxItem) => {
    onChange(item.value);
    setOpen(false);
    setQuery("");
  };

  const onKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setOpen(true);
      setActive((a) => Math.min(a + 1, results.length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActive((a) => Math.max(a - 1, 0));
    } else if (e.key === "Enter") {
      if (open && results[active]) {
        e.preventDefault();
        commit(results[active]);
      }
    } else if (e.key === "Escape") {
      setOpen(false);
      setQuery("");
      inputRef.current?.blur();
    }
  };

  return (
    <div ref={rootRef} className="relative">
      <button
        type="button"
        aria-haspopup="listbox"
        aria-expanded={open}
        onClick={() => {
          setOpen(true);
          setTimeout(() => inputRef.current?.focus(), 0);
        }}
        className="flex w-full items-center justify-between gap-2 rounded-md border border-border bg-surface/60 px-3 py-2 text-left font-mono text-sm text-foreground transition hover:border-primary/60 focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
      >
        <span className="min-w-0 truncate">
          {selected ? (
            <>
              <span className="text-primary">{selected.hint ?? selected.value}</span>
              <span className="text-muted-foreground"> · </span>
              <span>{selected.label}</span>
            </>
          ) : (
            <span className="text-muted-foreground">{placeholder}</span>
          )}
        </span>
        <ChevronDown className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
      </button>

      {open && (
        <div className="absolute left-0 right-0 top-full z-50 mt-1 overflow-hidden rounded-md border border-border bg-card/95 shadow-[var(--shadow-cockpit)] backdrop-blur animate-in fade-in slide-in-from-top-1 duration-150">
          <div className="flex items-center gap-2 border-b border-border/60 px-3 py-2">
            <Search className="h-3.5 w-3.5 text-muted-foreground" />
            <input
              ref={inputRef}
              role="combobox"
              aria-expanded={open}
              aria-controls={listboxId}
              aria-activedescendant={results[active] ? `${listboxId}-${results[active].value}` : undefined}
              autoComplete="off"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={onKeyDown}
              placeholder={placeholder}
              className="w-full bg-transparent font-mono text-sm text-foreground placeholder:text-muted-foreground focus:outline-none"
            />
            {query && (
              <button
                type="button"
                onClick={() => setQuery("")}
                className="text-muted-foreground hover:text-foreground"
                aria-label="Clear"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>
          {!query && pinned && pinned.length > 0 && (
            <div className="px-3 pt-2 font-mono text-[9px] uppercase tracking-widest text-muted-foreground">
              {pinnedLabel}
            </div>
          )}
          <ul
            ref={listRef}
            id={listboxId}
            className="max-h-72 overflow-y-auto py-1"
            role="listbox"
          >
            {results.length === 0 && (
              <li className="px-3 py-2 font-mono text-xs text-muted-foreground">
                {emptyLabel}
              </li>
            )}
            {results.map((it, i) => {
              const isActive = i === active;
              const isSelected = it.value === value;
              return (
                <li
                  key={it.value}
                  id={`${listboxId}-${it.value}`}
                  role="option"
                  aria-selected={isSelected}
                  onMouseEnter={() => setActive(i)}
                  onMouseDown={(e) => {
                    e.preventDefault();
                    commit(it);
                  }}
                  className={`flex cursor-pointer items-center justify-between gap-3 px-3 py-1.5 ${
                    isActive ? "bg-primary/15" : ""
                  }`}
                >
                  <div className="min-w-0">
                    <div className="flex items-baseline gap-2">
                      {it.hint && (
                        <span className="font-mono text-xs font-semibold text-primary">
                          {it.hint}
                        </span>
                      )}
                      <span className="truncate text-sm text-foreground">
                        {it.label}
                      </span>
                    </div>
                    {it.sub && (
                      <div className="truncate font-mono text-[10px] text-muted-foreground">
                        {it.sub}
                      </div>
                    )}
                  </div>
                  {isSelected && (
                    <span className="font-mono text-[9px] uppercase tracking-widest text-primary">
                      ✓
                    </span>
                  )}
                </li>
              );
            })}
          </ul>
          <div className="border-t border-border/60 px-3 py-1.5 font-mono text-[9px] uppercase tracking-widest text-muted-foreground">
            {results.length} of {items.length}
          </div>
        </div>
      )}
    </div>
  );
}