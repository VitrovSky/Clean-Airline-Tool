import { useCallback, useEffect, useState } from "react";

/**
 * Persist a small most-recently-used list of string ids in localStorage.
 * SSR-safe: reads happen only in the effect.
 */
export function useRecent(key: string, max = 6): [string[], (id: string) => void] {
  const [ids, setIds] = useState<string[]>([]);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(key);
      if (raw) setIds(JSON.parse(raw) as string[]);
    } catch {
      /* ignore */
    }
  }, [key]);

  const push = useCallback(
    (id: string) => {
      if (!id) return;
      setIds((prev) => {
        const next = [id, ...prev.filter((x) => x !== id)].slice(0, max);
        try {
          window.localStorage.setItem(key, JSON.stringify(next));
        } catch {
          /* ignore */
        }
        return next;
      });
    },
    [key, max],
  );

  return [ids, push];
}