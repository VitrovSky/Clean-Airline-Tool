/**
 * Domain types for the Silesian Airways Route Analyzer.
 *
 * Contract between the pure business-logic layer (src/lib/calc/*) and every
 * consumer (server functions, UI, reports, future Python/FastAPI port). No
 * framework or ORM references so the same shapes serialize cleanly to JSON,
 * HTTP, or Postgres.
 *
 * Units are explicit in field names to avoid ambiguity:
 *   distance  Km / Nm   speed  Kt      time   Minutes / Hours
 *   fuel      Kg        mass   Tonnes  money  EUR (always)
 */

// ---------- Aircraft ----------

export type AircraftCategory =
  | "turboprop"
  | "regional-jet"
  | "narrowbody"
  | "widebody";

export type AircraftOwnership = "leased" | "owned";

export interface Aircraft {
  id: string;
  manufacturer: string;
  model: string;
  category: AircraftCategory;

  // Performance
  cruiseSpeedKt: number;
  climbSpeedKt: number;
  descentSpeedKt: number;
  maxRangeNm: number;
  serviceCeilingFt: number;
  mtowTonnes: number;

  // Capacity
  passengerCapacity: number;
  cargoCapacityKg: number;
  maxPayloadKg: number;

  // Phased fuel (Jet A-1, kg)
  taxiFuelKg: number;             // combined taxi-out + taxi-in
  climbFuelKg: number;            // fixed climb burn per sector
  cruiseFuelKgPerHour: number;
  descentFuelKg: number;          // fixed descent burn per sector
  contingencyFuelPct: number;     // fraction of trip fuel
  alternateFuelKg: number;        // fixed reserve for diversion
  holdReserveFuelKg: number;      // 45-min final reserve

  // Phase durations (minutes)
  taxiOutMinutes: number;
  taxiInMinutes: number;
  climbTimeMinutes: number;
  descentTimeMinutes: number;

  // Crew complement
  crewCockpit: number;
  crewCabin: number;

  // Ground ops
  turnaroundMinutes: number;

  // Maintenance (EUR)
  airframeMaintEurPerFh: number;
  engineReserveEurPerFh: number;
  apuMaintEurPerCycle: number;

  // Ownership
  ownership: AircraftOwnership;
  monthlyLeaseEur: number;        // 0 when owned
  purchasePriceEur: number;       // 0 when leased
  depreciationYears: number;      // used when owned
  annualInsuranceEur: number;
  annualUtilizationHours: number;

  // Provenance — every aircraft cites its source
  dataSource: string;
}

// ---------- Airport ----------

export type AirportCategory =
  | "major-hub"
  | "regional"
  | "secondary"
  | "small";

export interface Airport {
  icao: string;
  iata: string | null;
  name: string;
  city: string;
  country: string; // ISO 3166-1 alpha-2
  latitude: number;
  longitude: number;
  elevationFt: number;
  runwayLengthM: number;
  category: AirportCategory;

  /** Landing fee per tonne of MTOW (EUR). */
  landingFeeEurPerTonne: number;
  /** Flat passenger service charge per departing pax (EUR). */
  paxServiceChargeEur: number;
  /** Flat ground handling cost per turnaround (EUR). */
  handlingFeeEur: number;
  /** Parking fee per hour on the ground (EUR). */
  parkingFeeEurPerHour: number;
  /** Optional per-airport security fee — falls back to settings default. */
  securityFeeEurPerPax?: number;
}

// ---------- Route request ----------

/**
 * Fully-resolved operational assumptions. The server function materialises
 * this from settings.json + per-request user overrides so calc modules
 * never touch config directly.
 */
export interface RouteAssumptions {
  fuelPriceEurPerKg: number;
  loadFactor: number;              // 0..1
  competitorFareEur: number;
  targetMarginPct: number;

  eurocontrolUnitRateEur: number;
  navMtowFactor: number;

  cockpitCrewEurPerCrewPerBlockHour: number;
  cabinCrewEurPerCrewPerBlockHour: number;

  cateringEurPerPax: number;
  cleaningEurPerFlight: number;
  isDeicingSeason: boolean;
  deicingFeeEur: number;

  co2KgPerFuelKg: number;
  carbonPriceEurPerTonneCO2: number;

  salesDistributionPctOfRevenue: number;
  cardFeesPctOfRevenue: number;
  marketingPctOfRevenue: number;
  ancillaryEurPerPax: number;

  adminPctOfDirectCost: number;

  delayReservePctOfDirectCost: number;
  contingencyPctOfVariable: number;

  /** Fallback security fee used when the airport does not publish its own. */
  securityFeeEurPerPaxDefault: number;
}

export interface RouteRequest {
  departureIcao: string;
  destinationIcao: string;
  aircraftId: string;
  assumptions: RouteAssumptions;
}

// ---------- Analysis output ----------

export interface FlightProfile {
  distanceKm: number;
  distanceNm: number;

  taxiOutMinutes: number;
  climbMinutes: number;
  cruiseMinutes: number;
  descentMinutes: number;
  taxiInMinutes: number;
  flightTimeMinutes: number;
  blockTimeMinutes: number;

  taxiFuelKg: number;
  climbFuelKg: number;
  cruiseFuelKg: number;
  descentFuelKg: number;
  tripFuelKg: number;
  contingencyFuelKg: number;
  alternateFuelKg: number;
  holdReserveFuelKg: number;
  totalFuelKg: number;
}

export interface CostBreakdown {
  // Fuel
  fuel: number;
  // Crew
  flightCrew: number;
  cabinCrew: number;
  // Maintenance
  airframeMaintenance: number;
  engineReserve: number;
  apuMaintenance: number;
  // Ownership
  lease: number;
  depreciation: number;
  insurance: number;
  // Airport
  landing: number;
  parking: number;
  handling: number;
  paxService: number;
  security: number;
  // Air navigation
  navigation: number;
  // Cabin ops
  catering: number;
  cleaning: number;
  deicing: number;
  // Environmental
  carbon: number;
  // Commercial (revenue-tied)
  salesDistribution: number;
  cardFees: number;
  marketing: number;
  // Reserves
  delayReserve: number;
  contingency: number;
  // Overhead
  adminOverhead: number;
  // Totals
  directSubtotal: number;
  variableSubtotal: number;
  total: number;
}

export interface RevenueBreakdown {
  passengers: number;
  ticketRevenue: number;
  ancillaryRevenue: number;
  total: number;
}

export type ProfitabilityClass =
  | "highly-profitable"
  | "profitable"
  | "break-even"
  | "risky"
  | "not-recommended";

export interface RouteAnalysis {
  request: RouteRequest;
  profile: FlightProfile;
  cost: CostBreakdown;
  revenue: RevenueBreakdown;
  costPerPassenger: number;
  breakEvenLoadFactor: number;
  suggestedFareEur: number;
  profitEur: number;
  marginPct: number;
  classification: ProfitabilityClass;
  notes: string[];
}

// ---------- Configuration ----------

/** Shape of src/lib/config/settings.json. */
export interface AppSettings {
  currency: "EUR";
  fuel: {
    priceEurPerKg: number;
    co2KgPerFuelKg: number;
    carbonPriceEurPerTonneCO2: number;
  };
  crew: {
    cockpitEurPerCrewPerBlockHour: number;
    cabinEurPerCrewPerBlockHour: number;
  };
  navigation: {
    eurocontrolUnitRateEur: number;
    mtowFactor: number;
  };
  airportDefaults: {
    securityFeeEurPerPax: number;
    deicingFeeEur: number;
  };
  cabin: {
    cateringEurPerPax: number;
    cleaningEurPerFlight: number;
  };
  commercial: {
    salesDistributionPctOfRevenue: number;
    cardFeesPctOfRevenue: number;
    marketingPctOfRevenue: number;
    ancillaryEurPerPax: number;
  };
  overhead: { adminPctOfDirectCost: number };
  reserves: {
    delayReservePctOfDirectCost: number;
    contingencyPctOfVariable: number;
  };
  pricing: { targetMarginPct: number };
  loadFactor: { default: number };
}
